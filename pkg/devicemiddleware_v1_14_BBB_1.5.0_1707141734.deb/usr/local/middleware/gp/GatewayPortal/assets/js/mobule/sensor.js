
/**
 *
 * 센서 (대시보드에서만 사용)
 *
 */

 (function () {

	var all_list = false;
	var device_list;
	var tmp_device_list;
	var sensor_list = [];
	var sensor_info_timer;
	var BASE_DOM = false;

	var isSensorListLoading = false;

	window.sensor = {

		MaxCount : 0,
		show_status : true,

		init : function (show_status, all) {

			var that = this;
			
			this.show_status = show_status

			BASE_DOM = $(".dashboard_list li.sensor:first").clone();
			$(".dashboard_list li.sensor:first").remove();

			if (all) all_list = all;

			this.start();
		},

		// 센서 리스트 요청
		load_list : function () {

			if(isSensorListLoading) return;
			isSensorListLoading = true;
			var that = this;
			
			ipc.send("getDevice", false, function (res) {
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

					device_list = res.DM_DEVICE_ID;

					if (that.show_status) that._start();
				}
				isSensorListLoading = false;
			});
		},
		start : function () {
			var that = this;
			that.load_list();
			sensor_info_timer = setInterval(function () {
				that.load_list();
			}, Config.Repeat.Sensor);
		},

		// 센서 정보 요청 타이머 시작
		_start : function () {
			var that = this;
			sensor_list = [];
			tmp_device_list = device_list.slice(0);
			that.all_load_data();
			/*sensor_info_timer = setInterval(function () {
				tmp_device_list = device_list.slice(0);
				sensor_list = [];
				that.all_load_data();
			}, Config.Repeat.Sensor);*/
		},

		// 센서 정보 요청 타이머 종료
		end : function () {
			clearInterval(sensor_info_timer);
		},

		// 센서 정보 요청
		all_load_data : function () {

			var that = this;

			// 등록된 디바이스 목록으로 센서리스트를 다 불러왓으면..
			if (tmp_device_list && tmp_device_list.length <= 0) {
				that.refreshUI();

				// 에러카운트
				if(device_list && device_list.length > 0) 
					dash_timer.error_count();

				return;
			}

			var deviceID = tmp_device_list[0];
			tmp_device_list.shift();
			
			var params = new Params();
			params.put("DM_DEVICE_ID", deviceID);
			ipc.send("getAllDeviceSensorStatus", params, function (res) {
				
//				if (res.DM_RESULT != IPC.DM_RESULT_SUCCESS) {
				for (var p in res.DM_SENSOR_ARRAY) sensor_list.push(res.DM_SENSOR_ARRAY[p]);
				
				that.all_load_data();
//				}
			});
		},

		// 센서정보 UI 변경
		refreshUI : function () {

			if (sensor_list) {

				$(".dashboard_list .sensor").remove();
				$("#sel_01 .dyn").remove();
				$("#sel_01 option").remove();
				$("#sel_01").append('<option value="all">All</option>');
				$("#sel_01").append('<option value="Device">Device</option>');
				$("#sel_01").append('<option value="Sensor">Sensor All</option>');
				
				for (var p in sensor_list) {
				
					var sensor = sensor_list[p];

					var li = BASE_DOM.clone();
					li.attr("id", sensor.DM_DEVICE_ID + "_" + sensor.DM_SENSOR_ID);

					var DM_DEVICE_ID = sensor.DM_DEVICE_ID;
					var DM_SENSOR_ID = sensor.DM_SENSOR_ID;
					var DM_SENSOR_NAME = sensor.DM_SENSOR_NAME;
					var DM_SENSOR_TYPE = sensor.DM_SENSOR_TYPE;
					var DM_SENSOR_STATUS = (sensor.DM_SENSOR_STATUS == "N/A") ? sensor.DM_SENSOR_STATUS : JSON.parse(sensor.DM_SENSOR_STATUS);
					var DM_SENSOR_DATA = "";

					// 이름
					if (DM_DEVICE_ID == "DEV-0") li.find(".tit").html("GW > " + DM_SENSOR_TYPE + "_" + Number(DM_SENSOR_ID) );
					else li.find(".tit").html("GW > " + DM_DEVICE_ID + " > " + DM_SENSOR_TYPE + "_" + Number(DM_SENSOR_ID) );

					if (sensor.DM_SENSOR_DATA == "N/A") {
						DM_SENSOR_DATA = sensor.DM_SENSOR_DATA;
					}else if(DM_SENSOR_TYPE == "undefined"){
						DM_SENSOR_DATA = sensor.DM_SENSOR_DATA;
						if(DM_SENSOR_DATA.length > 30) DM_SENSOR_DATA = DM_SENSOR_DATA.substring(0,23) + "...";
						li.find(".sensor_value").attr("data-tooltip-text", sensor.DM_SENSOR_DATA);
					}else {
						DM_SENSOR_DATA = JSON.parse(sensor.DM_SENSOR_DATA);
					}

					// 이미지 
					var sensor_image = DM_SENSOR_TYPE;
					if (DM_SENSOR_TYPE == "custom" || 
						DM_SENSOR_TYPE == "buzzer" || 
						DM_SENSOR_TYPE == "pressure" || 
						DM_SENSOR_TYPE == "ph" || 
						DM_SENSOR_TYPE == "percent" || 
						DM_SENSOR_TYPE == "complex" || 
						DM_SENSOR_TYPE == "string" || 
						DM_SENSOR_TYPE == "number"
					)
					sensor_image = "undefined";

					li.find(".sensor_status img").attr("src", "/assets/images/icon/icon-" + sensor_image + "-small.png");

					// 연결상태
					if (DM_SENSOR_STATUS != "N/A" && DM_SENSOR_STATUS.status == "on") {

						li.find(".onLine_status p").removeClass("errorText").text("Online");
						li.find(".dsc").hide().siblings().show();

						// 값 설정
						try {
							if (!DM_SENSOR_DATA.value && DM_SENSOR_DATA) {
								li.find(".value").text(DM_SENSOR_DATA);
							} else if (DM_SENSOR_DATA.value) {
								li.find(".value").text(DM_SENSOR_DATA.value);
							}
						} catch (e){
							li.find(".value").text(DM_SENSOR_DATA);
						}

					} else {
						li.find(".onLine_status p").addClass("errorText").text("Offline");
						li.find(".dsc").show().siblings().hide();
					}

					$(".dashboard_list").append(li);
					li.show();
					
					// 로그쪽 장비 셀렉트박스 
					$("#sel_01").append(
							'<option value="' + sensor.DM_DEVICE_ID + "_" +sensor.DM_SENSOR_ID + '">'  
							+ sensor.DM_DEVICE_ID + " > " +sensor.DM_SENSOR_TYPE + '</option>'
							);
				}
			}
		}
	};

 })();