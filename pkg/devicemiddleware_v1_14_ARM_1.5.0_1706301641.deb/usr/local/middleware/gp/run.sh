#!/bin/sh
node GatewayPortal.js 800 tcp://192.168.0.41:6001 tcp://192.168.0.41:6000