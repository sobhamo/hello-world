
/**
 *
 * 사용자 JS 컨피그
 *
 */

var Config = {

	PingHost						:	"google.co.kr",		// ping 테스트 주소
	Ajax							:	30,					// ajax 딜레이
	Timeout							:	30000,				// ajax timeout
	UpgradeCheck					:	5000,				// 업그레이드 후 완료 체크

	StartTime : {	// 1회성 시작 시간
		DashboardLoading			:	100,				// 대시보드 로딩
		Dashboard					:	500,				// 대시보드 타이머
		Sensor						:	900,				// 센서 정보 타이머
		History						:	2000				// 히스토리 타이머
	},

	Repeat : {	// 주기적인 타이머
		Ping						:	30000,				// 핑 타이머(Do not edit) - ping
		Dashboard					:	15000,				// 대시보드 타이머(Do not edit) - getSystemUsage, getProcessStatus
		Sensor						:	15000,				// 센서정보 타이머 - getDevice, getAllDeviceSensorStatus
		History						:	15000				// 히스토리 타이머(Do not edit) - getSystemLog
	},
	History : {	// 히스토리 설정
		Count : 15
	}
};

	
window.__ = function (msg) {	// locale 팩
	var lang = {
		"ko" : {
			"ThingPlug와 정상적으로 연결 됨" : "ThingPlug와 정상적으로 연결 됨",
			"센서" : "센서",
			"인터넷이 정상적으로 연결됨" : "인터넷이 정상적으로 연결됨",
			"네트워크 연결상태를 확인하세요" : "네트워크 연결상태를 확인하세요",
			"동적 IP 할당 방식" : "동적 IP 할당 방식",
			"정적 IP 할당 방식" : "정적 IP 할당 방식",
			"이미 등록 되어있는 디바이스 입니다" : "이미 등록 되어있는 디바이스 입니다.",
			"아이디를 입력하세요" : "아이디를 입력하세요.",
			"비밀번호를 입력하세요" : "비밀번호를 입력하세요.",
			"로그인에 실패하였습니다" : "로그인에 실패하였습니다.",
			"이미 등록 되어있는 디바이스 입니다" : "이미 등록 되어있는 디바이스 입니다.",
			"이미 등록 되어있는 디바이스 아이디입니다" : "이미 등록 되어있는 디바이스 아이디입니다.",
			"확인되었습니다" : "확인되었습니다.",
			"디바이스 ID를 입력하세요" : "디바이스 ID를 입력하세요.",
			"디바이스 패스코드를 입력하세요" : "디바이스 패스코드를 입력하세요.",
			"서비스 ID를 입력하세요" : "서비스 ID를 입력하세요.",
			"제조사 ID를 입력하세요" : "제조사 ID를 입력하세요.",
			"MAC 주소를 입력하세요" : "MAC 주소를 입력하세요.",
			"Port 번호를 입력하세요" : "Port 번호를 입력하세요.",
			"로그인 되었습니다" : "로그인 되었습니다.",
			"정보확인 하셔야 됩니다" : "정보확인 하셔야 됩니다.",
			"숫자만 입력하세요" : "숫자만 입력하세요.",
			"연결이 원할하지 않습니다" : "연결이 원할하지 않습니다.",
			"연결되었습니다" : "연결되었습니다.",
			"현재 비밀번호를 입력하세요" : "현재 비밀번호를 입력하세요.",
			"정상적으로 변경되었습니다" : "정상적으로 변경되었습니다.",
			"비밀번호가 일치하지 않습니다" : "비밀번호가 일치하지 않습니다.",
			"변경에 실패하였습니다" : "변경에 실패하였습니다.",
			"변경할 비밀번호가 일치하지 않습니다" : "변경할 비밀번호가 일치하지 않습니다.",
			"적용 완료" : "적용 완료",
			"적용 실패" : "적용 실패",
			"최소 10초 입력하세요" : "최소 10초 입력하세요.",
			"최대 3600초 입력하세요" : "최대 3600초 입력하세요.",
			"최소 10초 입력하세요" : "최소 10초 입력하세요.",
			"최소 1초 입력하세요" : "최소 1초 입력하세요.",
			"최대 3600초 입력하세요" : "최대 3600초 입력하세요.",
			"수집주기는 등록주기보다 빨라야 합니다" : "수집주기는 등록주기보다 빨라야 합니다.",
			"저장되었습니다" : "저장되었습니다.",
			"저장에 실패하였습니다" : "저장에 실패하였습니다.",
			"재실행" : "재실행",
			"초기화" : "초기화",
			"변경할 파일 이름을 입력하여 주세요" : "변경할 파일 이름을 입력하여 주세요",
			"변경할 ThingPlug 주소를 입력하여 주세요" : "변경할 ThingPlug 주소를 입력하여 주세요",
			"로그아웃": "로그아웃",
			"로그인": "로그인",
			"기기등록": "기기등록",
			"기기해지": "기기해지",
			"등록 완료" : "등록 완료",
			"기기해지 완료" : "기기해지 완료",
			"로그아웃 완료" : "로그아웃 완료",
			"로그인 성공" : "로그인 성공",
			"로그인 실패" : "로그인 실패",
			"로그인이 필요합니다" : "로그인이 필요합니다",
			"ThingPlug 연동상태" : "ThingPlug 연동상태",
			"ThingPlug에 기기등록 되었습니다" : "ThingPlug에 기기등록 되었습니다",
			"ONEM2M 프로토콜 버전을 선택하세요" : "ONEM2M 프로토콜 버전을 선택하세요",
			"5회이상 실패. 10초간 로그인이 정지됩니다." : "5회이상 실패. 10초간 로그인이 정지됩니다.",
			"10회이상 실패. 1분간 로그인이 정지됩니다." : "10회이상 실패. 1분간 로그인이 정지됩니다.",
			"20회이상 실패. 1시간 로그인이 정지됩니다." : "20회이상 실패. 1시간 로그인이 정지됩니다.",
			"아이디는 5자 이상으로 입력해주세요!" : "아이디는 5자 이상으로 입력해주세요!",
			"아이디는 15자 이내로 입력해주세요!" : "아이디는 15자 이내로 입력해주세요!",
			"패스워드는 9자 이상으로 입력해주세요!" : "패스워드는 9자 이상으로 입력해주세요!",
			"패스워드는 20자 이내로 입력해주세요!" : "패스워드는 20자 이내로 입력해주세요!",
			"패스워드는 영문자를 포함해야합니다." : "패스워드는 영문자를 포함해야합니다.",
			"패스워드는 숫자를 포함해야합니다." : "패스워드는 숫자를 포함해야합니다.",
			"패스워드는 특수문자를 포함해야합니다." : "패스워드는 특수문자를 포함해야합니다.",
			"시간이 초과하여 초기화면으로 이동합니다." : "시간이 초과하여 초기화면으로 이동합니다.",
			"업그레이드" : "업그레이드",
			"이미 업그레이드 되었습니다." : "이미 업그레이드 되었습니다.",
			"Please enter type" : "Type을 입력하세요",
			"Please enter index" : "Index를 입력하세요",
			"Please enter driver" : "Driver를 입력하세요",
			"Please enter interval" : "Interval을 입력하세요",
			"Please select datatype" : "Datatype을 입력하세요",
			"Please enter maxinterval" : "Maxinterval을 입력하세요",
			"Please select category" : "Category를 입력하세요",
			"Please enter value" : "값을 입력하세요",
			"ID 중복. Index 수정 필요" : "ID 중복. Index 수정 필요",
			"적용 완료. 15초 후에 다시 로그인하십시오." : "적용 완료. 15초 후에 다시 로그인하십시오.",
			"CSEBase ID를 입력하세요": "CSEBase ID를 입력하세요",
			"디바이스 이름을 입력하세요": "디바이스 이름을 입력하세요",
			"APP AE-ID를 입력하세요": "APP AE-ID를 입력하세요"
		},
		"en" : {
			"ThingPlug와 정상적으로 연결 됨" : "ThingPlug and normally being connected",
			"센서" : "Sensor",
			"인터넷이 정상적으로 연결됨" : "connected to the Internet",
			"네트워크 연결상태를 확인하세요" : "Please check your network connection",
			"동적 IP 할당 방식" : "Dynamic IP allocation scheme",
			"정적 IP 할당 방식" : "Static IP allocation scheme",
			"이미 등록 되어있는 디바이스 입니다" : "이미 등록 되어있는 디바이스 입니다.",
			"아이디를 입력하세요" : "Please enter ID",
			"비밀번호를 입력하세요" : "Please enter password",
			"로그인에 실패하였습니다" : "Login failed",
			"이미 등록 되어있는 디바이스 입니다" : "Already registered device",
			"이미 등록 되어있는 디바이스 아이디입니다" : "Already registered device ID",
			"확인되었습니다" : "Confirmed",
			"디바이스 ID를 입력하세요" : "Please enter device ID",
			"디바이스 패스코드를 입력하세요" : "Please enter device passcode",
			"서비스 ID를 입력하세요" : "Please enter service ID",
			"제조사 ID를 입력하세요" : "Please enter manufacturer ID",
			"MAC 주소를 입력하세요" : "Please enter device MAC address",
			"Port 번호를 입력하세요" : "Please enter port number",
			"로그아웃": "Logout",
			"로그인": "Login",
			"기기등록": "Register",
			"기기해지": "Unregister",
			"로그인 되었습니다" : "Login successful",
			"정보확인 하셔야 됩니다" : "You should login first",
			"숫자만 입력하세요" : "Please enter only numbers",
			"연결이 원할하지 않습니다" : "Connection is unstable",
			"연결되었습니다" : "Connection successful",
			"현재 비밀번호를 입력하세요" : "Please enter current password",
			"정상적으로 변경되었습니다" : "Successfully updated",
			"비밀번호가 일치하지 않습니다" : "Wrong current password",
			"변경에 실패하였습니다" : "Update failed",
			"변경할 비밀번호가 일치하지 않습니다" : "Password mismatch",
			"적용 완료" : "Update successful",
			"적용 실패" : "Update failure",
			"최소 10초 입력하세요" : "It should be more than 10 seconds",
			"최대 3600초 입력하세요" : "It should be less than 3600 seconds",
			"최소 10초 입력하세요" : "It should be more than 10 seconds",
			"최대 3600초 입력하세요" : "It should be less than 3600 seconds",
			"수집주기는 등록주기보다 빨라야 합니다" : "Collection interval should be shorter than registration interval",
			"저장되었습니다" : "Saved successfully",
			"저장에 실패하였습니다" : "Save failed",
			"재실행" : "Restart",
			"초기화" : "Reset",
			"변경할 파일 이름을 입력하여 주세요" : "Please enter new configuration file name",
			"변경할 ThingPlug 주소를 입력하여 주세요" : "Please Enter new ThingPlug server URL",
			"등록 완료" : "Registration success",
			"기기해지 완료" : "Unregistration success",
			"로그아웃 완료" : "Logout success",
			"로그인 성공" : "Login success",
			"로그인 실패" : "Login failure",
			"로그인이 필요합니다" : "Please login first!",
			"ThingPlug 연동상태" : "ThingPlug connection status",
			"ThingPlug에 기기등록 되었습니다" : "Device is registered to ThingPlug",
			"ONEM2M 프로토콜 버전을 선택하세요" : "Please select ONEM2M protocol version",
			"5회이상 실패. 10초간 로그인이 정지됩니다." : "Login failure over 5 times. 10 seconds suspended",
			"10회이상 실패. 1분간 로그인이 정지됩니다." : "Login failure over 10 times. 1 minute suspended",
			"20회이상 실패. 1시간 로그인이 정지됩니다." : "Login failure over 20 times. 1 hour suspended",
			"아이디는 5자 이상으로 입력해주세요!" : "ID should be more than 5 letters",
			"아이디는 15자 이내로 입력해주세요!" : "ID should be less than 15 letters",
			"패스워드는 9자 이상으로 입력해주세요!" : "Password should be more than 9 letters",
			"패스워드는 20자 이내로 입력해주세요!" : "Password should be less than 20 letters",
			"패스워드는 영문자를 포함해야합니다." : "Password should include alphabet",
			"패스워드는 숫자를 포함해야합니다." : "Password should include number",
			"패스워드는 특수문자를 포함해야합니다." : "Password should include non-alphanumeric",
			"시간이 초과하여 초기화면으로 이동합니다." : "Redirect to homepage due to page timeout",
			"업그레이드" : "Upgrade",
			"Please enter type" : "Please enter type",
			"Please enter index" : "Please enter index",
			"Please enter driver" : "Please enter driver",
			"Please enter interval" : "Please enter interval",
			"Please select datatype" : "Please select datatype",
			"Please enter maxinterval" : "Please enter maxinterval",
			"Please select category" : "Please select category",
			"Please enter value" : "Please enter value",
			"ID 중복. Index 수정 필요" : "ID dublicate. Check index",
			"적용 완료. 15초 후에 다시 로그인하십시오." : "Sucessfully updated",
			"CSEBase ID를 입력하세요": "Please enter CSEBase ID",
			"디바이스 이름을 입력하세요": "Please enter Device Name",
			"APP AE-ID를 입력하세요": "Please enter APP AE-ID"
		}
	};
	return lang[_locale][msg];
}
