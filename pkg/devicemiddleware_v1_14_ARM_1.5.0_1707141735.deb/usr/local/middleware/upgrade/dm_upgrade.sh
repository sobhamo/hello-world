dpkg -i /tmp/dm_upgrade_file
