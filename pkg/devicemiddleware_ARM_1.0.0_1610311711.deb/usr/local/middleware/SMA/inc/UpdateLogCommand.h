/**
 * @file UpdateLogCommand.h
 *
 * @brief getDeviceSensorInfo Command Process
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef __UPDATE_LOG_COMMAND_H__
#define __UPDATE_LOG_COMMAND_H__

#include "BaseCommand.h"

/// Log Type Enum
typedef enum tagLogType {
	LOG_TYPE_NONE           = 0,
	LOG_TYPE_GATEWAY_PORTAL = 1,
	LOG_TYPE_SENSOR         = 3,
	LOG_TYPE_MAX
}LOG_TYPE_E;

/// Log Level Enum
typedef enum tagLogLevel {
	LOG_LEVEL_NORMAL   = 0,
	LOG_LEVEL_MINOR    = 1,
	LOG_LEVEL_MAJOR    = 2,
	LOG_LEVEL_CRITICAL = 3,
}LOG_LEVEL_E;

/*
 ****************************************
 * Public Functions
 ****************************************
 */

void MakeUpdateLogMessage(int errorno, char* logData, char* sensorID);
int  UpdateLogCommandProcess(SPTekRECEIVE_MESSAGE_T *receiveMessage, char *contents, int length, SPTekSEND_MESSAGE_T *sendMessage);
void SetTraceStatus(SENSOR_TRACE_STATUS_E status);
void SetRegisterFlag(int flag);
int GetRegisterFlag(void);

#endif // __UPDATE_LOG_COMMAND_H__
