/*
 * @file undefine.h
 *
 * @brief Undefine Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _UNDEFINE_H_
#define _UNDEFINE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief UNDEFINED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int UNDEFINEDInit(void *ops);

/**
 * @brief UNDEFINED device UNDEFINED value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int UNDEFINEDRead(char *data, int *len);

/**
 * @brief UNDEFINED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int UNDEFINEDClose(void);


#endif //_UNDEFINE_H_
