/*
 * @file RGB_LED.h
 *
 * @brief RGB_LED Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _RGB_LED_H_
#define _RGB_LED_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief RGB_LED device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int RGB_LEDInit(void *ops);

/**
 * @brief RGB_LED device LED value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int RGB_LEDRead(char *data, int *len);

/**
 * @brief RGB_LED device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int RGB_LEDClose(void);


/**
 * @brief RGB_LED device LED value read funciton
 * @param[in] data Control data
 * @param[in] len  Control data length
 * @return	 result Result string
 */
char* RGB_LEDControl(char *data, int len);
#endif //_RGB_LED_H_
