/*
 * @file bh1750.h
 *
 * @brief Humidity Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */

#ifndef _BH1750_H_
#define _BH1750_H_

/*
 **************************************** 
 * Major Functions
 **************************************** 
 */


/**
 * @brief BH1750 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int BH1750Init(void *ops);

/**
 * @brief BH1750 device value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int BH1750Read(char *data, int *len);

/**
 * @brief BH1750 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BH1750Close(void);

#endif//_BH1750_H_
