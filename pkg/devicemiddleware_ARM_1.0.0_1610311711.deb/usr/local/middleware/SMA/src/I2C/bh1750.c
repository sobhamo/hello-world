/**
 * @file bh1750.c
 *
 * @brief Illuminance Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include "bh1750.h"
#include "Foundation.h"
#include "SensorManager.h"

/*
 **************************************** 
 * Definition & Global Variable
 **************************************** 
 */
#define ILLUMINANCE_ADDRESS 0x23
#define BUFF_SIZE           32
#define ADAPTER_NUMBER      1
#define DEV_I2C_NUMBER      "/dev/i2c-%d"

static int gBH1750Fd;

/*
 **************************************** 
 * BH1750 device Main Handle Functions 
 **************************************** 
 */

/**
 * @brief BH1750 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open 
 */
int BH1750Init(void *ops)
{
	SENSOR_OPERATIONS_T *operations = (SENSOR_OPERATIONS_T *)ops;

	operations->Read = BH1750Read;
	operations->Close = BH1750Close;
	operations->Control = NULL;
	return 0;
}

/**
 * @brief BH1750 device value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation 
 * 		-3 => Error read operation 
 */
int BH1750Read(char *data,int *len)
{
	char fileName[20];
	char buf[2];
	char sensorData[2];
	int   writeByte = 0;
	int   readByte = 0;
	float value;
	

	memset(fileName, 0, 20);
	memset(buf, 0, 2);
	snprintf(fileName, 19, DEV_I2C_NUMBER, ADAPTER_NUMBER);

	gBH1750Fd = open(fileName, O_RDWR);
	if(gBH1750Fd < 0) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}

	if(ioctl(gBH1750Fd, I2C_SLAVE, ILLUMINANCE_ADDRESS) < 0) {
		sprintf(data,"N/A:IOCTL");
		*len = strlen(data);
		close(gBH1750Fd);
        return 0;
    }

	(void)memset(buf,0,2); //BUFF_SIZE);
	(void)memset(sensorData,0,2);
	buf[0] = 0x11;
	writeByte = write(gBH1750Fd, buf, 1);
	if(writeByte < 0) {
		sprintf(data,"N/A:WRITE");
		*len = strlen(data);
		close(gBH1750Fd);
		return 0;
	}

	(void)memset(buf,0,2); //BUFF_SIZE);
	readByte = read(gBH1750Fd, buf, 2); //BUFF_SIZE);
	if(readByte <= 0) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		close(gBH1750Fd);
		return 0;
	}

	lseek(gBH1750Fd,0,SEEK_SET);

	(void)memset(buf,0,2);//BUFF_SIZE);
	readByte = read(gBH1750Fd, buf, 2); //BUFF_SIZE);
	if(readByte <= 0) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		close(gBH1750Fd);
		return 0;
	}

	sensorData[0] = (int)buf[0];
	sensorData[1] = (int)buf[1];

	value = (((256*sensorData[0]) + sensorData[1]) / 1.2);
	sprintf(data,"%.3f",value);
	*len = strlen(data);

	if(gBH1750Fd < 0) {
		sprintf(data,"N/A:CLOSE");
		*len = strlen(data);
		return 0;
	}
	close(gBH1750Fd);
	return 0;
}

/**
 * @brief BH1750 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BH1750Close(void)
{
	return 0;
}







