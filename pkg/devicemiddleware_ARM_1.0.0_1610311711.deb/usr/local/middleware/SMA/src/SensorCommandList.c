/**
 * @file SensorCommandList.c
 *
 * @brief Sensor command list container manager
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Foundation.h"
#include "SensorCommandList.h"

/*
 ****************************************
 * Public Functions
 ****************************************
 */

static COMMAND_LIST_T gSensorCommandList;

/**
 * @brief Init command list container
 * @param[in] Command list pointer
 * @return Void
 */
void SensorCommandListInit(void)
{
	gSensorCommandList.mCount   = 0;
	gSensorCommandList.mLengths = 0;
	gSensorCommandList.mHead    = NULL;
}

/**
 * @brief Sensor list insert node
 * @param[in]  list            Command list pointer
 * @param[in]  commandName     Command name 
 * @param[in]  nameLength      Command name length
 * @param[in]  commandFunction Command function pointer 
 * @param[in]  position        Insert position 
 * @return	 ERROR_TYPE_SUCCESS
 *           ERROR_TYPE_INVALID_PARAM
 *           ERROR_TYPE_MEMORY_LACK
 */
int SensorCommandListInsertNode(COMMAND_LIST_T *list, char commandTag, char *commandName, int nameLength, char* (*commandFunction)(char*), int position)
{
	int i = 0;
	if(position < 1 || position > (list->mCount) + 1) {
		return ERROR_TYPE_INVALID_PARAM;
	}

	if(commandName == NULL || nameLength < 1) {
		return ERROR_TYPE_INVALID_PARAM;
	}

	COMMAND_NODE_T *nodeData = (COMMAND_NODE_T *)calloc(1, sizeof(COMMAND_NODE_T));
	if(nodeData == NULL) {
		return ERROR_TYPE_MEMORY_LACK;
	}

	nodeData->mCommandTag = commandTag;
	
	nodeData->mCommandName = (char *)calloc(nameLength+1,sizeof(char));
	if(nodeData->mCommandName == NULL) {
		free(nodeData);
		return ERROR_TYPE_MEMORY_LACK;
	}
	(void)memcpy(nodeData->mCommandName,commandName,nameLength);
	nodeData->mNameLength  = nameLength;
	nodeData->mCommandFunction = commandFunction;

	if(position == 1) {
		nodeData->mNextNode = list->mHead;
		list->mHead         = nodeData;
	} else {
		COMMAND_NODE_T *nextNode = list->mHead;
		for(i=0; i<position-2; i++) {
			nextNode = nextNode->mNextNode;
		}
		nodeData->mNextNode = nextNode->mNextNode;
		nextNode->mNextNode = nodeData;
	}
	list->mLengths += nameLength;
	list->mCount++;

	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Sensor list add node
 * @param[in]  list            Command list pointer
 * @param[in]  commandName     Command name 
 * @param[in]  nameLength      Command name length
 * @param[in]  commandFunction Command function pointer 
 * @return	 ERROR_TYPE_SUCCESS
 *           ERROR_TYPE_INVALID_PARAM
 *           ERROR_TYPE_MEMORY_LACK
 */
int SensorCommandListAddNode(COMMAND_LIST_T *list, char commandTag, char *commandName, int nameLength, char* (*commandFunction)(char*))
{
	int i = 0;

	if(commandName == NULL || nameLength < 1) {
		return ERROR_TYPE_INVALID_PARAM;
	}

	COMMAND_NODE_T *nodeData = (COMMAND_NODE_T *)calloc(1, sizeof(COMMAND_NODE_T));
	if(nodeData == NULL) {
		return ERROR_TYPE_MEMORY_LACK;
	}

	nodeData->mCommandName = (char *)calloc(nameLength+1,sizeof(char));
	if(nodeData->mCommandName == NULL) {
		free(nodeData);
		return ERROR_TYPE_MEMORY_LACK;
	}

	nodeData->mCommandTag = commandTag;

	(void)memcpy(nodeData->mCommandName,commandName,nameLength);
	nodeData->mNameLength  = nameLength;
	nodeData->mCommandFunction = commandFunction;

	if(list->mCount == 0) {
		nodeData->mNextNode = list->mHead;
		list->mHead         = nodeData;
	} else {
		COMMAND_NODE_T *nextNode = list->mHead;
		for(i=0; i<list->mCount-1; i++) {
			nextNode = nextNode->mNextNode;
		}
		nodeData->mNextNode = NULL;
		nextNode->mNextNode = nodeData;
	}
	list->mLengths += nameLength;
	list->mCount++;
	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Get Sensor list Node
 * @param[in] list     Command list pointer
 * @param[in] position Target position
 * @return	COMMAND_NODE_T Success
 *		 	NULL           Error
 */
COMMAND_NODE_T* SensorCommandListGetPositionNode(COMMAND_LIST_T* list, int position)
{
	int i = 0;
	if(position < 1 || position > (list->mCount)) {
		return NULL;
	}

	COMMAND_NODE_T *nodeData = list->mHead;
	if(position == 1) {
		return nodeData;
	}

	for(i=0; i<position-1; i++) {
		if(nodeData == NULL) {
			break;
		}
		nodeData = nodeData->mNextNode;
	}
	return nodeData;
}

/**
 * @brief Get Sensor list Node
 * @param[in] list         Command list pointer
 * @param[in] commandName  Taget command name
 * @return	SPTekTLV_T node  => Success
 *		 	NULL             => Error
 */
COMMAND_NODE_T* SensorCommandListGetNameNode(COMMAND_LIST_T* list, char *commandName)
{
	int i                      = 0;
	COMMAND_NODE_T *searchNode = NULL;
	COMMAND_NODE_T *nodeData   = list->mHead;
	if(nodeData == NULL) {
		return searchNode;
	}

	for(i=0; i<list->mCount; i++) {
		if(nodeData == NULL) {
			break;
		}

		if(strcmp(nodeData->mCommandName,commandName) == 0) {
			searchNode = nodeData;
			break;
		}
		nodeData = nodeData->mNextNode;
	}
	return searchNode;
}

/**
 * @brief Get Sensor list Node
 * @param[in] list         Command list pointer
 * @param[in] commandName  Taget command name
 * @return	SPTekTLV_T node  => Success
 *		 	NULL             => Error
 */
COMMAND_NODE_T* SensorCommandListGetTagNode(COMMAND_LIST_T* list, char commandTag)
{
	int i                      = 0;
	COMMAND_NODE_T *searchNode = NULL;
	COMMAND_NODE_T *nodeData   = list->mHead;
	if(nodeData == NULL) {
		return searchNode;
	}

	for(i=0; i<list->mCount; i++) {
		if(nodeData == NULL) {
			break;
		}

		if(nodeData->mCommandTag == commandTag) {
			searchNode = nodeData;
			break;
		}
		nodeData = nodeData->mNextNode;
	}
	return searchNode;
}

/**
 * @brief Delete Sensor list Node
 * @param[in] list        Command list pointer
 * @param[in] commandName Target Name
 * @return	ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 */
int SensorCommandListDeleteTagNode(COMMAND_LIST_T *list, char commandTag)
{
	int i = 0;
	COMMAND_NODE_T *deleteNode = NULL;
	COMMAND_NODE_T *nodeData   = list->mHead;

	if(nodeData == NULL) {
		return ERROR_TYPE_FAIL;
	}

	if(nodeData->mCommandTag == commandTag) {
		list->mHead = nodeData->mNextNode;
		if(nodeData->mCommandName != NULL) {
			free(nodeData->mCommandName);
		}
		free(nodeData);
		return ERROR_TYPE_SUCCESS;
	}

	for(i=1; i<list->mCount; i++) {
		if(nodeData->mNextNode == NULL) {
			return ERROR_TYPE_FAIL;
		}

		if(nodeData->mNextNode->mCommandTag == commandTag) {
			deleteNode = nodeData->mNextNode;
			nodeData->mNextNode = deleteNode->mNextNode;
			if(deleteNode->mCommandName != NULL) {
				free(deleteNode->mCommandName);
			}
			free(deleteNode);
			break;
		}
		nodeData = nodeData->mNextNode;
	}

	list->mCount--;
	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Delete Sensor list Node
 * @param[in] list        Command list pointer
 * @param[in] commandName Target Name
 * @return	ERROR_TYPE_SUCCESS
 *          ERROR_TYPE_INVALID_PARAM
 */
int SensorCommandListDeleteNode(COMMAND_LIST_T *list, char *commandName)
{
	int i = 0;
	COMMAND_NODE_T *deleteNode = NULL;
	COMMAND_NODE_T *nodeData   = list->mHead;

	if(nodeData == NULL) {
		return ERROR_TYPE_FAIL;
	}

	if(strncmp(nodeData->mCommandName,commandName,strlen(commandName)) == 0) {
		list->mHead = nodeData->mNextNode;
		if(nodeData->mCommandName != NULL) {
			free(nodeData->mCommandName);
		}
		free(nodeData);
		return ERROR_TYPE_SUCCESS;
	}


	for(i=1; i<list->mCount; i++) {
		if(nodeData->mNextNode == NULL) {
			return ERROR_TYPE_FAIL;
		}

		if(strncmp(nodeData->mNextNode->mCommandName,commandName,strlen(commandName)) == 0) {
			deleteNode = nodeData->mNextNode;
			nodeData->mNextNode = deleteNode->mNextNode;
			if(deleteNode->mCommandName != NULL) {
				free(deleteNode->mCommandName);
			}
			free(deleteNode);
			break;
		}
		nodeData = nodeData->mNextNode;
	}

	list->mCount--;
	return ERROR_TYPE_SUCCESS;
}

/**
 * @brief Delete all sensor Node
 * @param[in] list Command list pointer
 * @return	Void
 */
void SensorCommandListDeleteAllNode(COMMAND_LIST_T *list)
{
	int i = 0;
	if(list == NULL) {
		return;
	}

	if(list->mCount == 0) {
		SensorCommandListInit();
		return;
	}

	COMMAND_NODE_T *deleteNode = list->mHead;
	if(deleteNode == NULL) {
		SensorCommandListInit();
		return;
	}

	for(i=0; i<list->mCount; i++) {
		if(deleteNode == NULL) {
			continue;
		}
		COMMAND_NODE_T *nextNode = deleteNode->mNextNode;
		if(deleteNode->mCommandName!= NULL) {
			free(deleteNode->mCommandName);
		}
		free(deleteNode);
		deleteNode = nextNode;
	}
	SensorCommandListInit();
}

/**
 * @brief Print all sensor node
 * @param[in] list Command list pointer
 * @return	Void
 */
void SensorCommandListPrintNode(COMMAND_LIST_T *list)
{
	COMMAND_NODE_T *nodeData = list->mHead;
	printf("List : ");
	while(nodeData != NULL) {
		if(nodeData->mCommandName != NULL) {
			printf("mCommandName : %s\n", nodeData->mCommandName);
		}
		printf("mNameLength : %d\n", nodeData->mNameLength);
		printf("mCommandFunction : %p\n", nodeData->mCommandFunction);
		nodeData = nodeData->mNextNode;
	}
	printf("\n");
	printf("Total: %d value(s)\n",list->mCount);
}


/**
 * @brief Register sensor command 
 * @param[in]    commandName     Command Name
 * @param[in]    commandFunction Command Function Pointer
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int RegisterSensorCommand(char commandTag, char *commandName, char* (*commandFunction)(char*))
{
	int ret = ERROR_TYPE_SUCCESS;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);

	if(node != NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Already registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	node = SensorCommandListGetTagNode(&gSensorCommandList, commandTag);

	if(node != NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Already registered command tag <%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	if( commandTag < 0x80 || commandTag > 0x9f) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Tag range over <%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	ret = SensorCommandListAddNode(&gSensorCommandList, commandTag, commandName, strlen(commandName), commandFunction);

	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Register Fail!<%x><%s>", commandTag, commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Cancel registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int CancelSensorCommand(char *commandName)
{
	int ret = ERROR_TYPE_SUCCESS;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}

	ret = SensorCommandListDeleteNode(&gSensorCommandList, commandName);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Register Fail!<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}


/**
 * @brief Execute registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int ExecuteSensorCommand(char *commandName, char *commandArg, char *result)
{
	int ret = ERROR_TYPE_SUCCESS;
	char *retResult;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetNameNode(&gSensorCommandList, commandName);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}

	retResult = node->mCommandFunction(commandArg);
	strcpy(result,retResult);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Execute Fail!<%s>",commandName);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Execute registered sensor command 
 * @param[in]    commandName     Command Name
 * @return ERROR_TYPE_SUCCESS
 *         ERROR_TYPE_FAIL
 */
int ExecuteSensorCommandTag(char commandTag, char *commandArg, char *result)
{
	int ret = ERROR_TYPE_SUCCESS;
	char *retResult;
	COMMAND_NODE_T *node = NULL;

	node = SensorCommandListGetTagNode(&gSensorCommandList, commandTag);
	if(node == NULL) {
		SPTekDebugLog(LOG_LEVEL_INFO,"Fail,Not registered command tag<%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}

	retResult = node->mCommandFunction(commandArg);
	strcpy(result,retResult);
	if(ret != ERROR_TYPE_SUCCESS){
		SPTekDebugLog(LOG_LEVEL_INFO,"Execute Fail!<%x>",commandTag);
		return ERROR_TYPE_FAIL;
	}
	return ret;
}

/**
 * @brief Get sensor control command Tag by position
 * @param[in]    positon List position
 * @return CommandTag  Get command tag by input position
 */
char GetSensorCommandTagPosition(int position)
{
	COMMAND_NODE_T *node = NULL;
	node = SensorCommandListGetPositionNode(&gSensorCommandList, position);
	if(node == NULL)
		return 0x00;
	return node->mCommandTag;
}

/**
 * @brief Get sensor control command name by position
 * @param[in]    positon List position
 * @return CommandName Get command name by input position
 */
char* GetSensorCommandNamePosition(int position)
{
	COMMAND_NODE_T *node = NULL;
	node = SensorCommandListGetPositionNode(&gSensorCommandList, position);
	if(node == NULL)
		return NULL;
	return node->mCommandName;
}

/**
 * @brief Execute registered sensor command 
 * @return Void
 */
int GetSensorCommandListCount(void)
{
	return gSensorCommandList.mCount;	
}



