
/**
 * @file Timer.h
 *
 * @brief Header for Timer API
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek 
 */

#ifndef _TIMER_H_
#define _TIMER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <time.h>
#include <pthread.h>

/*
 **************************************** 
 * Definitions
 **************************************** 
 */

typedef void (*timercb_fn)(void* parameter);

/*
 **************************************** 
 * Structure Definitions
 **************************************** 
 */

struct _Timer;

typedef struct {
    struct _Timer *head; 
    struct _Timer *last;
    pthread_mutex_t lock;    
} TimerList;

typedef struct _Timer {
    int                 sec;
    int                 nsec;
    int                 periodic;

    timer_t             timerID;
    timercb_fn          callback;
    void*               parameter;
	
    struct _Timer*      next;
} Timer ;

/*
 **************************************** 
 * Function Declarations
 **************************************** 
 */

int     DM_TimerInit(void);
void    DM_TimerTerm(void);

Timer*  SetTimer(int sec, int nsec, int periodic, void *cb, void *parameter);
void    CancelTimer(Timer** hTimer);

#ifdef __cplusplus
}
#endif

#endif /* _TIMER_H_ */

