/**
 * @file number.c
 *
 * @brief NUMBER Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "number.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gNUMBERNFd;

static char gDummyData[10][20] = 
	{"22123.5","4523323","23367.5","2390","2211.5","23.61124","323257.5","822310","20000.5","228932.5"};
static int gIndex = 0;

/*
 ****************************************
 * NUMBER device Main Handle Functions
 ****************************************
 */

/**
 * @brief NUMBER device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int NUMBERInit(void)
{
	//gNUMBERNFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief NUMBER device NUMBER value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int NUMBERRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief NUMBER device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int NUMBERClose(void)
{
	close(gNUMBERNFd);
	return 0;
}

/**
 * @brief NUMBER Extract NUMBER value
 * @param[in] Raw Data
 * @return 0 = NUMBER Value
 */
int getNUMBERValue(char *data)
{
	return 0;
}

