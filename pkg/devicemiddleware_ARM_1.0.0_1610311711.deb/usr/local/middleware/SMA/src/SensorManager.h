#ifndef __SENSOR_MANAGER_H__
#define __SENSOR_MANAGER_H__

#include <time.h>
#include <pthread.h>

#include "dm_list.h"

#define MAX_STR_LEN 64

extern DMList gSensorList;

typedef struct tagSensorOperations {
	int (*Close) (void);
	int (*Read) (char *data, int *length);
	char* (*Control) (char *command, int length);
}SENSOR_OPERATIONS_T;


typedef struct tagSensor {
	// User Setup Sensor Configurations
	char mID[MAX_STR_LEN];
	char mName[MAX_STR_LEN];
	char mType[MAX_STR_LEN];
	char mReadInterval[MAX_STR_LEN];
	int mMaxInterval;
	unsigned short mOperationType;
	unsigned short mControlType;

	// Auto Setup Sensor Configurations
	char mValue[MAX_STR_LEN];
	int mStartTime;
	unsigned short mStatus;

	// Sensor Operations
	SENSOR_OPERATIONS_T mOperations;
    pthread_mutex_t mReadMutex;
}SENSOR_T;


void SensorManagerInit(void);
void SensorManagerClose(void);
void *GetSensorListHead(void);

#endif //__SENSOR_MANAGER_H__
