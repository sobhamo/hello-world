﻿
/**
 *
 * 대시보드 타이머
 *
 */
 
 (function () {

	var isPing = false;
	var dashboard_timer;

	window.dash_timer = {

		MaxCount : 0,
		show_status : true,

		init : function () {
			this.start();
		},

		// 요청 타이머 시작
		start : function () {
			this.load_data();
			dashboard_timer = setInterval(this.load_data, Config.Repeat.Dashboard);
		},

		// 요청 타이머 종료
		end : function () {
			clearInterval(dashboard_timer);
		},

		// 정보 요청
		load_data : function () {

			var that = this;

			if (window.isPing) return;

			// 핑
			dash_timer.ping()

			// 사용량 정보
			dash_timer.getSystemUsage();

			// 장치 프로세스 정보
			dash_timer.getProcessStatus();

			// 에러카운트
			//dash_timer.error_count();
		}, 
		// 핑
		ping : function () {

			// 라인 초기화
			$("p.network_line, p.thingplug_line").removeClass("offline").removeClass("on");
			$("p.network_line img").attr("src", "/assets/images/icon/ajax-loader.gif").addClass("wait").show();
			$("p.thingplug_line img").attr("src", "/assets/images/icon/ajax-loader.gif").addClass("wait").show();

			ipc.send("ping", false, function (res) {

				//ipc.end();
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

					isPing = res.isAlive;

					if (res.isAlive) {
						$("p.network_line img").hide();
						$("p.network_line").removeClass("offline").addClass("on");
						$(".bt_ping").hide().prev().show();

						// Thingplug 상태
						dash_timer.getThingStatus();

					} else {
						//$("p.network_line img").hide();
						$("p.network_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
						$("p.network_line").removeClass("on").addClass("offline");
						$(".bt_ping").show().prev().hide();

						// thingplug
						//$("p.thingplug_line img").hide();
						$("p.thingplug_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
						$("p.thingplug_line").removeClass("on").addClass("offline");
						$("#DM_IOT_THING_STATUS").text("Offline").addClass("errorText");
						$(".device_info").hide();
						$(".device_check").show();
					}
				} else {
					//$("p.network_line img").hide();
					$("p.network_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
					$("p.network_line").removeClass("on").addClass("offline");
					$(".bt_ping").show().prev().hide();

					// thingplug
					//$("p.thingplug_line img").hide();
					$("p.thingplug_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
					$("p.thingplug_line").removeClass("on").addClass("offline");
					$("#DM_IOT_THING_STATUS").text("Offline").addClass("errorText");
					$(".device_info").hide();
					$(".device_check").show();
				}

				// Thingplug 상태
				//dash_timer.getThingStatus();
			});
		}, 
		// 사용량 정보
		getSystemUsage : function () {

			ipc.send("getSystemUsage", false, function (res) {

				//ipc.end();
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					// {DM_RESULT: 1, DM_CPU_USAGE: 97, DM_RAM_USAGE: 14.5, DM_BATTERY_USAGE: 20
					$("#DM_DEV_CPU_USAGE").css("width", Math.round(res.DM_DEV_CPU_USAGE) + "%");
					$("#DM_DEV_RAM_USAGE").css("width", Math.round(res.DM_DEV_RAM_USAGE) + "%");
					$("#DM_CPU_USAGE").css("width", Math.round(res.DM_CPU_USAGE) + "%");
					$("#DM_RAM_USAGE").css("width", Math.round(res.DM_RAM_USAGE) + "%");
					//$("#DM_BATTERY_USAGE").text(res.DM_DEV_BATTERY_USAGE + "%");

					var cpu = Math.round(res.DM_CPU_USAGE) + "% / " + Math.round(res.DM_DEV_CPU_USAGE) + "%";
					var ram = Math.round(res.DM_RAM_USAGE) + "% / " + Math.round(res.DM_DEV_RAM_USAGE) + "%";

					$("#DM_CPU_USAGE").parent().next().text(cpu);
					$("#DM_RAM_USAGE").parent().next().text(ram);
				}
			});
		},
		// 장치 프로세스 정보
		getProcessStatus : function () {
				
			ipc.send("getProcessStatus", false, function (res) {

				//ipc.end();

				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					// {DM_RESULT: 1, DM_SRA_PROCESS_STATUS: 1, DM_CRA_PROCESS_STATUS: 2, DM_MA_PROCESS_STATUS: 1}
					var gp_img = "";
					var sra_img = "";
					var ma_img = "";
					var cra_img = "";
					var sma_img = "";

					if (res.DM_SRA_PROCESS_STATUS == IPC.DM_PROCESS_LIVE_STATE) sra_img = "cir_green_s";
					else if (res.DM_SRA_PROCESS_STATUS == IPC.DM_PROCESS_KILL_STATE) sra_img = "cir_critical_s";
					else sra_img = "cir_gray_s";

					if (res.DM_CRA_PROCESS_STATUS == IPC.DM_PROCESS_LIVE_STATE) cra_img = "cir_green_s";
					else if (res.DM_CRA_PROCESS_STATUS == IPC.DM_PROCESS_KILL_STATE) cra_img = "cir_critical_s";
					else cra_img = "cir_gray_s";

					if (res.DM_MA_PROCESS_STATUS == IPC.DM_PROCESS_LIVE_STATE) ma_img = "cir_green_s";
					else if (res.DM_MA_PROCESS_STATUS == IPC.DM_PROCESS_KILL_STATE) ma_img = "cir_critical_s";
					else ma_img = "cir_gray_s";

					if (res.DM_SMA_PROCESS_STATUS == IPC.DM_PROCESS_LIVE_STATE) sma_img = "cir_green_s";
					else if (res.DM_SMA_PROCESS_STATUS == IPC.DM_PROCESS_KILL_STATE) sma_img = "cir_critical_s";
					else sma_img = "cir_gray_s";

					$(".ds_status .sra img").attr("src", "/assets/images/icon/" + sra_img + ".png");
					$(".ds_status .ma img").attr("src", "/assets/images/icon/" + ma_img + ".png");
					$(".ds_status .cra img").attr("src", "/assets/images/icon/" + cra_img + ".png");
					$(".ds_status .sma img").attr("src", "/assets/images/icon/" + sma_img + ".png");
				} else {
					$(".ds_status .sra img").attr("src", "/assets/images/icon/cir_critical_s.png");
					$(".ds_status .ma img").attr("src", "/assets/images/icon/cir_critical_s.png");
					$(".ds_status .cra img").attr("src", "/assets/images/icon/cir_critical_s.png");
					$(".ds_status .sma img").attr("src", "/assets/images/icon/cir_critical_s.png");
				}
			});
		},
		// Thingplug 상태
		getThingStatus : function () {

			//if (!isPing) return;

			// 라인 초기화
			$("p.thingplug_line").removeClass("offline").removeClass("on");
			$("p.thingplug_line img").attr("src", "/assets/images/icon/ajax-loader.gif").addClass("wait").show();

			ipc.send("getThingStatus", false, function (res) {
			
				//ipc.end();

				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					// {DM_RESULT: 1, DM_IOT_DEV_REG_STATE: 2, DM_IOT_THING_STATUS: 1}
					if (res.DM_IOT_THING_STATUS == IPC.DM_THING_ONLINE) {
						$("p.thingplug_line img").hide();
						$("#DM_IOT_THING_STATUS").text("Online").removeClass("errorText");
						$("p.thingplug_line").removeClass("offline").addClass("on");
						$(".device_info").show();
						$(".device_check").hide();
					} else {
						//$("p.thingplug_line img").hide();
						$("p.thingplug_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
						$("p.thingplug_line").removeClass("on").addClass("offline");
						$("#DM_IOT_THING_STATUS").text("Offline").addClass("errorText");
						$(".device_info").hide();
						$(".device_check").show();
					}
				} else {
					//$("p.thingplug_line img").hide();
					$("p.thingplug_line img").attr("src", "/assets/images/icon/off_x.png").removeClass("wait");
					$("p.thingplug_line").removeClass("on").addClass("offline");
					$("#DM_IOT_THING_STATUS").text("Offline").addClass("errorText");
					$(".device_info").hide();
					$(".device_check").show();
				}
			});
		},
		// 에러 카운트
		error_count : function () {

			ipc.send("getErrorLogCount", false, function (res) {

				//ipc.end();
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

					// 디바이스
					var DM_CRITICAL_COUNT = res.DM_CRITICAL_COUNT;
					var DM_MAJOR_COUNT = res.DM_MAJOR_COUNT;
					var DM_MINOR_COUNT = res.DM_MINOR_COUNT;

					$("em#DM_CRITICAL_COUNT").text(DM_CRITICAL_COUNT);
					$("em#DM_MAJOR_COUNT").text(DM_MAJOR_COUNT);
					$("em#DM_MINOR_COUNT").text(DM_MINOR_COUNT);

					// 센서별
					if (res.DM_SENSOR_ARRAY && res.DM_SENSOR_ARRAY.length > 0) {
						for (var p in res.DM_SENSOR_ARRAY) {
							
							var errorCount = res.DM_SENSOR_ARRAY[p];
							var DM_DEVICE_ID = errorCount.DM_DEVICE_ID;
							var DM_SENSOR_ID = errorCount.DM_SENSOR_ID;
							
							DM_CRITICAL_COUNT = errorCount.DM_CRITICAL_COUNT;
							DM_MAJOR_COUNT = errorCount.DM_MAJOR_COUNT;
							DM_MINOR_COUNT = errorCount.DM_MINOR_COUNT;

							var parent = $("#" + DM_DEVICE_ID + "_" + DM_SENSOR_ID);

							parent.find(".DM_CRITICAL_COUNT").text(DM_CRITICAL_COUNT);
							parent.find(".DM_MAJOR_COUNT").text(DM_MAJOR_COUNT);
							parent.find(".DM_MINOR_COUNT").text(DM_MINOR_COUNT);
						}
					}
				}
			});
		}
	};
 })();
