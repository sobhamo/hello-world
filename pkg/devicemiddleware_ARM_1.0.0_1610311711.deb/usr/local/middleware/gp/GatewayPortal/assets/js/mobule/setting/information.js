
/**
 *
 * 환경설정 > 관리자 설정
 *
 */

(function () {
	
	var isAuthOneM2M = false;
	var DM_IOT_DEV_REG_STATE;
	var DM_IOT_UKEY;

	$(function () {
		
		//ipc.start();

		init();

		$("[name='p_version']").on("change", function () {
			if($("#p_version option:selected").val() == "V1.12") {
				$(".onem2m").hide();
				$(".onem2m_v1_12").show();
			} else {
				$(".onem2m_v1_12").hide();
				$(".onem2m").show();
			}
		});

		onCheckStatus();

		// radiobox check event
		$("input[name=rdo_protocol]").bind("change", onCheckStatus);

		// OneM2M login & logout
		$(".bt_onem2m_check").click(function (e) {

			e.preventDefault();

			// OneM2M login process
			if( !$(this).hasClass("bt_onem2m_logout")) {

				if ($("input[name='onem2m_id']").Empty("ThingPlug " + __("아이디를 입력하세요"))) return;
				if ($("input[name='onem2m_pw']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return ;

				var ID = $("input[name='onem2m_id']").val().trim();
				var PASS = $("input[name='onem2m_pw']").val().trim();

				var params = new Params();
				params.put("ID", ID);
				params.put("PASS", PASS);

				ipc.start();

				// ThingPlug server Authentication
				setTimeout(function () {
					ipc.send("checkThingplugUserInfo", params, function (res) {

						if (!res.ThingPlug) {
							ipc.end();
							isAuthOneM2M = false;
							$("input[name='uKey']").val('');
							alert(__("로그인 실패"));
							return;
						}
							
						// if thingpluguser check result success
						if (res.ThingPlug.result_code[0] == 200) {
							$("input[name='uKey']").val(res.ThingPlug.user[0].uKey);
							
							var params1 = new Params();
							params1.put("DM_IOT_TP_ID", $("input[name='onem2m_id']").val().trim());
							params1.put("DM_IOT_UKEY", $("input[name='uKey']").val());	

							// console.log(params1);

							// Login to MA
							ipc.send("account", params1, function (res) {
								
								ipc.end();

								if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {	

									// When login success, disable ID & PASS input and change button text and class
									$(".bt_onem2m_check.bt_cbtn").text(__("로그아웃"));
									$(".bt_onem2m_check.bt_cbtn").addClass("bt_onem2m_logout");	

									$("[name='onem2m_id']").prop('disabled', true);
									$("[name='onem2m_pw']").prop('disabled', true);
								
									isAuthOneM2M = true;
									alert(__("로그인 되었습니다"));							
								}else{
									isAuthOneM2M = false;
									$("input[name='uKey']").val('');
									alert(__("로그인 실패"));																			
								}												
							});
							
						} else {	// 인증실패
							ipc.end();
							alert(res.ThingPlug.result_msg[0]);
						}
					});
				}, 500);
				
			}else{
			// oneM2M logout process

			
				var params = new Params();
				params.put("DM_UNREGI_TYPE", IPC.DM_ACCOUNT);

				ipc.start();

				setTimeout(function () {
					ipc.send("unregisterDevice", params, function (res) {

						ipc.end();

						if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
							$(".guideMsg").hide();					

							$("[name='onem2m_id']").val('');							
							$("[name='onem2m_id']").prop('disabled', false);
							$("[name='onem2m_pw']").val('');
							$("[name='onem2m_pw']").prop('disabled', false);
							$("[name='onem2m_device_id']").val('');
							$("[name='onem2m_device_id']").prop('disabled', false);
							$("[name='onem2m_passcode']").val('');
							$("[name='onem2m_passcode']").prop('disabled', false);
							
							$("[name='gmmp_service_id']").val('');
							$("[name='gmmp_service_id']").prop('disabled', false);
							$("[name='gmmp_create_id']").val('');
							$("[name='gmmp_create_id']").prop('disabled', false);
							$("[name='gmmp_macaddress']").val('');
							$("[name='gmmp_macaddress']").prop('disabled', false);
							$("[name='gmmp_port']").val('');
							$("[name='gmmp_port']").prop('disabled', false);	
						
							$("[name='rdo_protocol']").prop('disabled', false);
							$("[name='p_version']").prop('disabled', false);
							$("[name='platform'] option").eq(0).prop("selected", true);
							$("[name='platform']").prop("disabled", false);	
							
							$(".bt_onem2m_check.bt_cbtn").text(__("로그인"));
							$(".bt_onem2m_check.bt_cbtn").removeClass("bt_onem2m_logout");			
							$(".bt_submit.bt_cbtnB.bt_red").text(__("기기등록"));
							$(".bt_submit.bt_cbtnB.bt_red").removeClass("bt_device_cancel");
							
							$("input[name='uKey']").val('');
							isAuthOneM2M = false;
							alert(__("로그아웃 완료"));		
						}else{
							alert(__("적용 실패"));
						}

					});
				}, 500);				
				
			}
		});
		

		// Device registration & unregistration
		$(".bt_submit").click(function (e) {

			e.preventDefault();
			
			// device registration
			if( !$(this).hasClass("bt_device_cancel")) {

				var type = $("input[name=rdo_protocol]:checked").val();

				var isValidation = false;

				var params = new Params();
				
				// if oneM2M protocol
				if (type != "GMMP") {
					if($("#p_version option:selected").val() == "V1.12") {
						isValidation = validationOneM2M_V1_12();
						if (isValidation) {
							params.put("DM_IOT_PROTOCOL_TYPE", $("#p_version option:selected").val());
							params.put("DM_IOT_TP_ID", $("input[name='onem2m_v1_12_id']").val().trim());
							params.put("DM_IOT_SC_PASS", $("input[name='onem2m_v1_12_pw']").val());
							params.put("DM_IOT_CSEBASE_ID", $("input[name='onem2m_csebase_id']").val().trim());
							params.put("DM_IOT_DEVICE_NAME", $("input[name='onem2m_device_name']").val().trim());
							params.put("DM_IOT_APP_AE_ID", $("input[name='onem2m_app_ae_id']").val().trim());
							params.put("DM_IOT_SERVICE_ID", $("input[name='onem2m_v1_12_service_id']").val().trim());
						}
					} else {
						isValidation = validationOneM2M();
						if (isValidation) {
							params.put("DM_IOT_PROTOCOL_TYPE", $("#p_version option:selected").val());
							params.put("DM_IOT_TP_ID", $("input[name='onem2m_id']").val().trim());
							//params.put("onem2m_pw", $("input[name='onem2m_pw']").val());
							params.put("DM_IOT_DEVICE_NAME", $("input[name='onem2m_device_id']").val().trim());
							params.put("DM_IOT_PASS_CODE", $("input[name='onem2m_passcode']").val().trim());
							params.put("DM_IOT_UKEY", $("input[name='uKey']").val().trim());
							//params.put("onem2m_mac", $("input[name='onem2m_mac']").val());
						}
					}
				} else {
				// if GMMP protocol
					isValidation = validationGMMP();
					if (isValidation) {
						params.put("DM_IOT_PROTOCOL_TYPE", type);
						params.put("DM_IOT_SERVICE_ID", $("input[name='gmmp_service_id']").val().trim());
						params.put("DM_IOT_MANUFACTURE_ID", $("input[name='gmmp_create_id']").val().trim());
						params.put("DM_IOT_AUTH_ID", $("input[name='gmmp_macaddress']").val().trim());
						params.put("DM_IOT_SERVER_PORT", $("input[name='gmmp_port']").val().trim());
					}
				}

				//params.put("userId", $("input[name='userId']").val());
				params.put("DM_IOT_SP_USE_FLAG", $( "select[name='platform'] option:selected" ).val());
				// params.put("DM_IOT_SP_USE_FLAG", $("input[name='platform']:checked").val() ? IPC.DM_IOT_SP_USE : IPC.DM_IOT_SP_NO_USE);

				console.log(params);
				// return;
				
				if (isValidation) {

					ipc.start();

					// 기존에 있는 정보 리셋
					ipc.send("reset", false, function (res) {
						if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
							// 기기 Thungplug 등록
							ipc.send("registerDevice", params, function (res) {
								
								ipc.end();

								if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
									
									$(".guideMsg").show();
		
									$(".bt_submit.bt_cbtnB.bt_red").text(__("기기해지"));
									$(".bt_submit.bt_cbtnB.bt_red").addClass("bt_device_cancel");
									
									$("[name='gmmp_service_id']").prop('disabled', true);
									$("[name='gmmp_create_id']").prop('disabled', true);
									$("[name='gmmp_macaddress']").prop('disabled', true);
									$("[name='gmmp_port']").prop('disabled', true);							
										
									$("[name='onem2m_device_id']").prop('disabled', true);
									$("[name='onem2m_passcode']").prop('disabled', true);
								
									$("[name='rdo_protocol']").prop('disabled', true);	
									$("[name='platform']").prop('disabled', true);	

									// if oneM2M protocol
									if ($("input[name=rdo_protocol]:checked").val() != "GMMP") {								
										$("[name='p_version']").prop('disabled', true);
									}									
																	
								
									alert(__("등록 완료"));
										
								} else if (res.DM_RESULT == IPC.DM_RESULT_ALEADY_REGISTERED) {
									alert(__("이미 등록 되어있는 디바이스 입니다"));
								} else if (res.DM_RESULT == IPC.DM_RESULT_OTHER_REGISTERED) {
									alert(__("이미 등록 되어있는 디바이스 아이디입니다"));
								} else if ((res.DM_RESULT == IPC.DM_RESULT_FAIL) && (res.DM_FAIL_MESSAGE != "") ) { 
									alert(__("적용 실패") + res.DM_FAIL_MESSAGE);
								} else if ((res.DM_RESULT == IPC.DM_RESULT_FAIL) && (res.DM_FAIL_MESSAGE == "") ) { 					
									alert(__("적용 실패"));
								}
							});
						}else{
							ipc.end();
							alert(__("적용 실패"));
						}
					});
				}
				
			}else{
			// device unregistration	
			
				var params = new Params();
				params.put("DM_UNREGI_TYPE", IPC.DM_DEVICE);

				ipc.start();

				setTimeout(function () {
					ipc.send("unregisterDevice", params, function (res) {

						ipc.end();

						if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

							$(".guideMsg").hide();
							$(".bt_submit.bt_cbtnB.bt_red").text(__("기기등록"));
							$(".bt_submit.bt_cbtnB.bt_red").removeClass("bt_device_cancel");	
							
							$("[name='rdo_protocol']").prop('disabled', false);	
							$("[name='platform'] option").eq(0).prop("selected", true);
							
							// if oneM2M protocol
							if ($("input[name=rdo_protocol]:checked").val() != "GMMP") {								
								isAuthOneM2M = true;
								$("[name='platform']").prop('disabled', false);	
								$("[name='p_version']").prop('disabled', false);
							}							
								
							$("[name='onem2m_device_id']").val('');
							$("[name='onem2m_device_id']").prop('disabled', false);
							$("[name='onem2m_passcode']").val('');
							$("[name='onem2m_passcode']").prop('disabled', false);	
							
							$("[name='gmmp_service_id']").val('');
							$("[name='gmmp_service_id']").prop('disabled', false);
							$("[name='gmmp_create_id']").val('');
							$("[name='gmmp_create_id']").prop('disabled', false);
							$("[name='gmmp_macaddress']").val('');
							$("[name='gmmp_macaddress']").prop('disabled', false);
							$("[name='gmmp_port']").val('');
							$("[name='gmmp_port']").prop('disabled', false);						

							alert(__("기기해지 완료"));							
							
						}else{
							alert(__("적용 실패"));
						}

					});
				}, 500);				
				
			}
		});
			
		

		// Thingplug 회원가입
		$(".bt_join").click(function (e) {

			e.preventDefault();

			window.open("thjoin", "IoTPortalPopup");
			$("#IoTPortalForm").submit();

		});
	});

	// oneM2M v1 유효성
	var validationOneM2M = function () {
		
		if ($("#p_version option:selected").val() == "" ) { 
			alert(__("ONEM2M 프로토콜 버전을 선택하세요")); 
			return false;
		}
		if ($("input[name='onem2m_id']").Empty("ThingPlug " + __("아이디를 입력하세요"))) return false;
		if ($("input[name='onem2m_pw']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return false;
		if ($("input[name='onem2m_device_id']").Empty(__("디바이스 ID를 입력하세요"))) return false;
		if ($("input[name='onem2m_passcode']").Empty(__("디바이스 패스코드를 입력하세요"))) return false;
		//if ($("input[name='onem2m_mac']").Empty("MAC 주소를 입력하세요.")) return false;
		// if not logined
		if (!isAuthOneM2M) {
			alert(__("로그인이 필요합니다"));
			return false;
		}

		return true;
	};

	// oneM2M v1.12 유효성
	var validationOneM2M_V1_12 = function () {
		if ($("input[name='onem2m_v1_12_id']").Empty("ThingPlug " + __("아이디를 입력하세요"))) return false;
		if ($("input[name='onem2m_v1_12_pw']").Empty("ThingPlug " + __("비밀번호를 입력하세요"))) return false;
		if ($("input[name='onem2m_csebase_id']").Empty(__("CSEBase ID를 입력하세요"))) return false;
		if ($("input[name='onem2m_v1_12_service_id']").Empty(__("서비스 ID를 입력하세요"))) return false;
		if ($("input[name='onem2m_device_name']").Empty(__("디바이스 이름을 입력하세요"))) return false;
		if ($("input[name='onem2m_app_ae_id']").Empty(__("APP AE-ID를 입력하세요"))) return false;
		return true;
	};

	// GMMP 유효성
	var validationGMMP = function () {
		if ($("input[name='gmmp_service_id']").Empty(__("서비스 ID를 입력하세요"))) return false;
		if ($("input[name='gmmp_create_id']").Empty(__("제조사 ID를 입력하세요"))) return false;
		if ($("input[name='gmmp_macaddress']").Empty(__("MAC 주소를 입력하세요"))) return false;
		if ($("input[name='gmmp_port']").Empty(__("Port 번호를 입력하세요"))) return false;
		if (isNaN($("input[name='gmmp_port']").val())) {
			$("input[name='gmmp_port']").focus();
			alert(__("숫자만 입력하세요"));
			return false;
		}
		return true;
	};

	// radiobox check
	var onCheckStatus = function () {
		if($(".rdo_onem2m").is(":checked")) {
			$(".onem2m_v1_12").hide();
			$(".gmmp").hide();
			$(".onem2m").show();
			$("[name='platform']").removeAttr("disabled");
			//$("[name='p_version']").removeAttr("disabled");
			$("[name='p_version'] option").eq(1).prop('selected',true);
			$("[name='p_version']").attr("disabled", "disabled");
		}
		else if($(".rdo_gmmp").is(":checked")) {
			$(".onem2m").hide();
			$(".onem2m_v1_12").hide();
			$(".gmmp").show();
			$("[name='platform'] option").eq(0).prop("selected", true);
			$("[name='platform']").prop('disabled', true);
			$("[name='p_version'] option").eq(0).prop('selected',true);
			$("[name='p_version']").attr("disabled", "disabled");
		}
	}

	// 페이지 초기화
	var init = function () {

		// 시스템 정보
		ipc.send("getSystemInfo", false, function (res) {

			//ipc.end();

			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}
				$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);
				$("#DM_CPU_TYPE").text(res.DM_CPU_TYPE);
				$("#DM_RAM_TYPE").text(res.DM_RAM_TYPE);
				$("#DM_BATTERY_TYPE").text(res.DM_BATTERY_TYPE);

				isNext = true;
				
				// if device is registered
				if ((res.DM_IOT_PROTOCOL_TYPE != undefined) && (res.DM_IOT_PROTOCOL_TYPE != "NONE") && (res.DM_IOT_PROTOCOL_TYPE != "")) {	// 기등록
					$(".guideMsg").show();
					// $(".bt_onem2m_check.bt_cbtn").text("로그아웃");
					// $(".bt_onem2m_check.bt_cbtn").addClass("bt_onem2m_logout");			
					$(".bt_submit.bt_cbtnB.bt_red").text(__("기기해지"));
					$(".bt_submit.bt_cbtnB.bt_red").addClass("bt_device_cancel");
					
					// if protocol is GMMP
					if (res.DM_IOT_PROTOCOL_TYPE == "GMMP")	{
						$(".rdo_gmmp").prop("checked", true).change();
						
						$("[name='gmmp_service_id']").val(res.DM_IOT_SERVICE_ID);
						$("[name='gmmp_service_id']").attr("disabled", "disabled");
						$("[name='gmmp_create_id']").val(res.DM_IOT_MANUFACTURE_ID);
						$("[name='gmmp_create_id']").attr("disabled", "disabled");
						$("[name='gmmp_macaddress']").val(res.DM_IOT_AUTH_ID);
						$("[name='gmmp_macaddress']").attr("disabled", "disabled");
						$("[name='gmmp_port']").val(res.DM_IOT_SERVER_PORT);
						$("[name='gmmp_port']").attr("disabled", "disabled");
					
					}else{
					// if protocol is oneM2M
						
						$(".bt_onem2m_check.bt_cbtn").text(__("로그아웃"));
						$(".bt_onem2m_check.bt_cbtn").addClass("bt_onem2m_logout");		
						
						$("[name='onem2m_id']").val(res.DM_IOT_TP_ID);
						$("[name='onem2m_id']").attr("disabled", "disabled");
						$("[name='onem2m_pw']").val("**********");
						$("[name='onem2m_pw']").attr("disabled", "disabled");
						$("[name='onem2m_device_id']").val(res.DM_IOT_DEVICE_NAME);
						$("[name='onem2m_device_id']").attr("disabled", "disabled");
						$("[name='onem2m_passcode']").val("**********");
						$("[name='onem2m_passcode']").attr("disabled", "disabled");
						
						if (res.DM_IOT_PROTOCOL_TYPE == "V1") {
							$("[name='p_version'] option").eq(1).prop('selected',true);
						}else{
							$("[name='p_version'] option").eq(2).prop('selected',true);
						}					
						$("[name='p_version']").attr("disabled", "disabled");
					}

					$("[name='rdo_protocol']").attr("disabled", "disabled");
					
					if (res.DM_IOT_SP_USE_FLAG == IPC.DM_IOT_SP) {
						$("[name='platform'] option").eq(1).prop("selected", true);
					}else if (res.DM_IOT_SP_USE_FLAG == IPC.DM_IOT_LORA) {
						$("[name='platform'] option").eq(2).prop("selected", true);
					}					
					// if (res.DM_IOT_SP_USE_FLAG == IPC.DM_IOT_SP_USE) { 	
						// $("[name='platform']").prop("checked", true); 
					// }
					$("[name='platform']").prop("disabled", true);
						
					
				} else {
				// if device is not registered
				
					$(".guideMsg").hide();
					$(".bt_onem2m_check.bt_cbtn").text(__("로그인"));
					$(".bt_submit.bt_cbtnB.bt_red").text(__("기기등록"));
					
					// if device is logined
					if (res.DM_IOT_TP_ID != undefined && res.DM_IOT_TP_ID != "") {
						
						$(".bt_onem2m_check.bt_cbtn").text(__("로그아웃"));
						$(".bt_onem2m_check.bt_cbtn").addClass("bt_onem2m_logout");	
							
						$("[name='onem2m_id']").val(res.DM_IOT_TP_ID);
						$("[name='onem2m_id']").attr("disabled", "true");
						$("[name='onem2m_pw']").val("**********");
						$("[name='onem2m_pw']").attr("disabled", "true");
						$("input[name='uKey']").val(res.DM_IOT_UKEY);
						DM_IOT_UKEY = res.DM_IOT_UKEY;
						isAuthOneM2M = true;
							
					}
				}				
							
				
			}
		});
		
	};
})();