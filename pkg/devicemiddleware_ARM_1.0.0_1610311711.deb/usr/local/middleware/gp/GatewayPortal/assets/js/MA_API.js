/**
 * http://usejsdoc.org/
 */

var encode = require("./encode");
var API = {};

module.exports = API;

//TEST용 module
var define = require('./define');

var push_Socket;



API.pushSocketRegister = function(_socket){
	push_Socket = _socket;
}


/*
	1000
	MA에 Connect 되고 수신 받을 준비가 되었는지를 알린다. 즉, Connect후 바로 register를 보낸다.
*/ 
API.register = function(){
	//console.log("register");
	API.sendData(define.REGISTER);
}


/*
	1012
	Confirmation to MA for IV receiving
*/ 

API.IV = function(){

	var content = {
		DM_RESULT	: 0x0001		// IV receive success notice
	}
	
	API.sendData(define.IV, content);
	content = null;
}


/*
	1001
	admin Auth 를 요청
*/ 
API.authentication = function(DM_ADMIN_ID, DM_ADMIN_PASSWD){
	//console.log("authentication");
	var content = {
		DM_ADMIN_ID 	: DM_ADMIN_ID,		// 디바이스 ID
		DM_ADMIN_PASSWD : DM_ADMIN_PASSWD,	// 센서이름
	}
	
	API.sendData(define.AUTHENTICATION, content);
	content = null;
}


/*
	1010
	Set and Get extraInfo like time setting
*/ 
API.extraInfo = function(DM_SERVER_URL, DM_TRACE_STATUS, DM_TIMEZONE, DM_SET_TIME, DM_TIME_SYNC ){
	//console.log("authentication");
	if (DM_SERVER_URL != undefined && DM_SERVER_URL != "") {
		var content = {
			DM_SERVER_URL 	: DM_SERVER_URL		// Set TP server URL
		}
	} else if (DM_TRACE_STATUS != undefined && DM_TRACE_STATUS != "") {
		var content = {
			DM_TRACE_STATUS 	: DM_TRACE_STATUS		// Set Trace status
		}
	} else if (DM_TIMEZONE != undefined && DM_TIMEZONE != "") {
		var content = {
			DM_TIMEZONE 	: DM_TIMEZONE		// Set Log timezone
		}
	} else if (DM_SET_TIME != undefined && DM_SET_TIME != "") {
		var content = {
			DM_SET_TIME 	: DM_SET_TIME		// Set Device time
		}
	} else if (DM_TIME_SYNC != undefined && DM_TIME_SYNC != "") {
		var content = {
			DM_TIME_SYNC 	: DM_TIME_SYNC		// Set Timeserver sync
		}
	} else {
		var content = null;
	}	
	
	API.sendData(define.EXTRA_INFO, content);
	content = null;
}


/*
	1002
	admin ID PASSWD 변경요청
*/ 
API.changeAuthentication = function(DM_ADMIN_ID, DM_ADMIN_PASSWD, DM_ADMIN_NEW_ID, DM_ADMIN_NEW_PASSWD){
	//console.log("changeAuthentication");
	var content = {
		DM_ADMIN_ID 		: DM_ADMIN_ID,			// 디바이스 ID
		DM_ADMIN_PASSWD 	: DM_ADMIN_PASSWD,		// 센서이름
		DM_ADMIN_NEW_ID 	: DM_ADMIN_NEW_ID,		// 디바이스 ID
		DM_ADMIN_NEW_PASSWD : DM_ADMIN_NEW_PASSWD,	// 센서이름
	}
	
	API.sendData(define.CHANGE_AUTH, content);
	content = null;
}



/*
	 1003
	 재구동을 요청한다
 */
API.restart = function(){
	//console.log("restart");
	API.sendData(define.RESTART);
}



/*
	 1004
	 재구동을 요청한다
 */
API.reset = function(){
	//console.log("reset");
	API.sendData(define.RESET);
}



/*
	1005
	자기 장치에 대한 정보요청
*/ 
API.getSystemInfo = function(){
	//console.log("getSystemInfo");
	API.sendData(define.GET_SYSTEM_INFO);
}



/*
	 1006
	 자기 장치에 대한 CPU, RAM, Battery 사용량정보요청
*/ 
API.getSystemUsage = function(){
	//console.log("getSystemUsage");
	API.sendData(define.GET_SYSTEM_USAGE);
}



/*
	 1007
	 자기 장치에 대한 네트워크 상태정보 요청
*/
API.getNetworkInfo = function(){
	//console.log("getNetworkInfo");
	API.sendData(define.GET_NETWORK_INFO);
}



/*
	 1008
	 자기 장치에 대한 Process 구동상태정보 요청
*/ 
API.getProcessStatus = function(){
	//console.log("getProcessStatus");
	API.sendData(define.GET_PROCESS_STATUS);
}


/*
	 1011
	 middleware auto upgrade
*/ 
API.middlewareUpgrade = function(){
	//console.log("middlewareUpgrade");
	API.sendData(define.MIDDLEWARE_UPGRADE);
}


/*
	1021
	자기 장치에 연결된 디바이스정보를 요청
*/ 
API.getDevice = function(){
	//console.log("getDevice");
	API.sendData(define.GET_DEVICE);
}



/*
	 1022
	 해당 디바이스에 연결된 센서정보를 요청
*/ 
API.getDeviceSensor = function(DM_DEVICE_ID){
	//console.log("getDeviceSensor");
	var content = {
		DM_DEVICE_ID 	: DM_DEVICE_ID,		// 디바이스 ID
	}
	API.sendData(define.GET_DEVICE_SENSOR, content);
	content = null;
}



/*
	1023
	자기 장치에 연결된 디바이스 및 센서상태정보를 요청
*/ 
API.getDeviceSensorStatus = function(DM_DEVICE_ID, DM_SENSOR_ID, DM_SENSOR_NAME, DM_SENSOR_TYPE){
	//console.log("getDeviceSensor");
	var content = {
		DM_DEVICE_ID 	: DM_DEVICE_ID,		// 디바이스 ID
		DM_SENSOR_ID 	: DM_SENSOR_ID,		// 센서 ID
		DM_SENSOR_NAME 	: DM_SENSOR_NAME,	// 센서이름
		DM_SENSOR_TYPE 	: DM_SENSOR_TYPE,	// 센서타입
	}
	API.sendData(define.GET_DEVICE_SENSOR_STATUS, content);
	content = null;
}



/*
	 1024
	 해당 디바이스의 모든 센서정보 및 센서상태정보를 요청
*/ 
API.getAllDeviceSensorStatus = function(DM_DEVICE_ID, DM_SENSOR_ARRAY){
	//console.log("getAllDeviceSensorStatus");

	if (DM_SENSOR_ARRAY != undefined && DM_SENSOR_ARRAY != "") {
		var content = {
			DM_DEVICE_ID 	: DM_DEVICE_ID,		// 디바이스 ID
			DM_SENSOR_ARRAY	: DM_SENSOR_ARRAY		// sensor array
		}
	} else {
		var content = {
			DM_DEVICE_ID 	: DM_DEVICE_ID		// 디바이스 ID
		}				
	}
	
	// console.log(content);
	
	API.sendData(define.GET_ALL_DEVICE_SENSOR_STATUS, content);
	content = null;
}


/*
	1009
	Device unRegistration from ThingPlug 
*/ 
API.account = function(DM_IOT_TP_ID, DM_IOT_UKEY){

	var content = {
		DM_IOT_TP_ID			: DM_IOT_TP_ID,			// ThingPlug ID
		DM_IOT_UKEY				: DM_IOT_UKEY			// ThingPlug Ukey
	}
		
		
	API.sendData(define.ACCOUNT, content);
	content = null;
}


/*
	1041
	자기장치를 ThingPlug에 등록한다 (oneM2M) 
*/ 
API.registerDevice_oneM2M = function(DM_IOT_DEVICE_NAME, DM_IOT_PASS_CODE, DM_IOT_SP_USE_FLAG, DM_IOT_UKEY, DM_IOT_TP_ID, DM_IOT_PROTOCOL_TYPE){
	//console.log("registerDevice");

	if(DM_IOT_UKEY != "") {
		
		var content = {
			DM_IOT_PROTOCOL_TYPE	: DM_IOT_PROTOCOL_TYPE,	// IOT Protocol 타입(“oneM2M” or “GMMP”)
			DM_IOT_DEVICE_NAME 		: DM_IOT_DEVICE_NAME,	// 장치이름
			DM_IOT_PASS_CODE 		: DM_IOT_PASS_CODE,		// 디바이스 패스코드
			DM_IOT_SP_USE_FLAG		: DM_IOT_SP_USE_FLAG, 	// SKT 서비스플랫폼 사용여부
			DM_IOT_UKEY				: DM_IOT_UKEY,			// UKEY
			DM_IOT_TP_ID			: DM_IOT_TP_ID			// ThingPlug ID
		}
		
	}else{

		var content = {
			DM_IOT_PROTOCOL_TYPE	: DM_IOT_PROTOCOL_TYPE,	// IOT Protocol 타입(“oneM2M” or “GMMP”)
			DM_IOT_DEVICE_NAME 		: DM_IOT_DEVICE_NAME,	// 장치이름
			DM_IOT_PASS_CODE 		: DM_IOT_PASS_CODE,		// 디바이스 패스코드
			DM_IOT_SP_USE_FLAG		: DM_IOT_SP_USE_FLAG, 	// SKT 서비스플랫폼 사용여부
			DM_IOT_TP_ID			: DM_IOT_TP_ID			// ThingPlug ID
		}
	}
	
	// console.log(content);
	
	API.sendData(define.REGISTER_DEVICE, content);
	content = null;
}



/*
	1041
	자기장치를 ThingPlug에 등록한다 (GMMP) 
*/ 
API.registerDevice_GMMP = function(DM_IOT_AUTH_ID, DM_IOT_SERVICE_ID, DM_IOT_SP_USE_FLAG, DM_IOT_MANUFACTURE_ID, DM_IOT_SERVER_PORT){
	//console.log("registerDevice");
	var content = {
		DM_IOT_PROTOCOL_TYPE 	: "GMMP",					// IOT Protocol 타입(“oneM2M” or “GMMP”)
		DM_IOT_AUTH_ID			: DM_IOT_AUTH_ID, 			// 인증ID(MAC Address or ISDN)
		DM_IOT_SERVICE_ID 		: DM_IOT_SERVICE_ID,		// 서비스ID
		DM_IOT_SP_USE_FLAG 		: DM_IOT_SP_USE_FLAG,		// SKT 서비스플랫폼 사용여부
		DM_IOT_MANUFACTURE_ID	: DM_IOT_MANUFACTURE_ID,	// 제조사ID
		DM_IOT_SERVER_PORT		: DM_IOT_SERVER_PORT		// 서비스ID 에 할당된 접속 port
	}
	API.sendData(define.REGISTER_DEVICE, content);
	content = null;
}


/*
	1009
	Device unRegistration from ThingPlug 
*/ 
API.unregisterDevice = function(DM_UNREGI_TYPE){

	var content = {
		DM_UNREGI_TYPE			: DM_UNREGI_TYPE			// unRegistration type
	}
		
	API.sendData(define.UNREGISTER_DEVICE, content);
	content = null;
}


/*
	1042
	미들웨어와 Thing 연결상태를 요청한다
*/ 
API.getThingStatus = function(){
	//console.log("getThingStatus");
	API.sendData(define.GET_THING_STATUS);
}



/*
	 1043
	 Sensor 정보 수집주기 및 Sensor 정보 ThingPlug 서버 등록 주기 정보를 요청
*/ 
API.getInterval = function(){
	//console.log("getInterval");
	API.sendData(define.GET_INTERVAL);
}



/*
	 1044
	 Sensor 정보 수집주기 및 Sensor 정보 ThingPlug 서버 등록 주기 설정	
*/ 
API.setInterval = function(DM_SENSOR_GATHER_INTERVAL, DM_SENSOR_SERVER_UPDATE_INTERVAL){
	//console.log("setInterval");
	
	var MAX_TIME = 3600;
	var MIN_TIME = 10;
	
	DM_SENSOR_GATHER_INTERVAL = Math.min(DM_SENSOR_GATHER_INTERVAL , MAX_TIME);
	DM_SENSOR_GATHER_INTERVAL = Math.max(DM_SENSOR_GATHER_INTERVAL , MIN_TIME);
	DM_SENSOR_SERVER_UPDATE_INTERVAL = Math.max(DM_SENSOR_GATHER_INTERVAL, DM_SENSOR_SERVER_UPDATE_INTERVAL);
	DM_SENSOR_SERVER_UPDATE_INTERVAL = Math.min(DM_SENSOR_SERVER_UPDATE_INTERVAL , MAX_TIME);
	DM_SENSOR_SERVER_UPDATE_INTERVAL = Math.max(DM_SENSOR_SERVER_UPDATE_INTERVAL , MIN_TIME);
	
	
	var content = {
			DM_SENSOR_GATHER_INTERVAL 			: DM_SENSOR_GATHER_INTERVAL,		// 센서정보수집주기
			DM_SENSOR_SERVER_UPDATE_INTERVAL 	: DM_SENSOR_SERVER_UPDATE_INTERVAL,	// 센서정보서버 UDPATE주기
		}
	API.sendData(define.SET_INTERVAL, content);
	content = null;
	MAX_TIME = null;
	MIN_TIME = null;
}



/*
	 1061
	 Trace ON/OFF 상태를 MA에 전달한다
*/ 
API.setTraceStatus = function(DM_TRACE_STATUS){
	//console.log("setTraceStatus");
	var content = {
		DM_TRACE_STATUS : DM_TRACE_STATUS
	}
	API.sendData(define.SET_TRACE_STATUS, content);
	content = null;
}



/*
	 1062
	 로그정보 업데이트시 이를 MA에 전달한다
 */
API.updateLog = function(DM_LOG_TYPE, DM_LOG_LEVEL, DM_LOG_DEVICE_ID, DM_LOG_SENSOR_ID, DM_LOG_DATA){
	
	//console.log("updateLog");
	
	var content = {
		DM_LOG_TYPE 		: DM_LOG_TYPE,
		DM_LOG_LEVEL 		: DM_LOG_LEVEL,
		DM_LOG_DEVICE_ID 	: DM_LOG_DEVICE_ID,
		DM_LOG_SENSOR_ID 	: DM_LOG_SENSOR_ID,
		DM_LOG_DATA			: DM_LOG_DATA
	}
	API.sendData(define.UPDATE_LOG, content);
	content = null;
}



/*
	 1063
	 로그정보를 요청한다. (미들웨어와 ThingPlug연동로그 및 미들웨어와 센서 연동로그 포함)
*/ 
API.getSystemLog = function(DM_LOG_TYPE, DM_LOG_NEXT_KEY, DM_LOG_COUNT){
	//console.log("getSystemLog");
	var content = {
		DM_LOG_TYPE 	: DM_LOG_TYPE,		// 디바이스 ID
		DM_LOG_NEXT_KEY : DM_LOG_NEXT_KEY,	// 센서이름
		DM_LOG_COUNT 	: DM_LOG_COUNT,		// 센서타입
	}
	API.sendData(define.GET_SYSTEM_LOG, content);
	content = null;
	
}



/*
	 1064
	 자기 장치에 연결된 모든 디바이스, 센서의 레벨별 오류카운트를 요청\
 */
API.getErrorLogCount = function(){
	//console.log("getErrorLogCount");
	API.sendData(define.GET_ERROR_LOG_COUNT);
}



/*
	1065
	로그정보를 초기화한다
*/
API.logReset = function(){
	//console.log("logReset");
	API.sendData(define.LOG_RESET);
}




API.sendData = function(contentType, content){
	
	if(!push_Socket){
		throw "Push Socket is not Registered";
	}	
	
	// 패킷 생성후 0x00으로 초기화
	var packet = new Buffer(2048);
	packet.fill(0x00);
	
	var totalByteLength = 48;
	if(content){
		totalByteLength = encode.encodeContent(packet, contentType, content);	
	}
	packet = encode.encodeHeader(packet, contentType, totalByteLength);
//	packet = packet.slice(0, totalByteLength);	
	packet = packet.slice(0, Math.ceil(totalByteLength / 16)*16);	
	
	//console.log("sending packet");
	//console.log(Date());
	//console.log(packet);
	push_Socket.write(packet);
	
	if(define.IV == contentType ){
		define.encrptionIV = define.encrptionTempIV
	}
	
	packet = null;
}















