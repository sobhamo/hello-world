/**
 * http://usejsdoc.org/
 */
var encode = {};

module.exports = encode;

var define = require('./define');
var crypto = require('crypto');


encode.encodeHeader = function(packet, messageType, totalByteLength) {
	
	var lengthStirng;
	
	if(totalByteLength){
		var contentLength = totalByteLength - define.DEFAULT_HEADER_OFFSET;
		lengthStirng  = Math.floor(contentLength / 1000 % 10).toString();
		lengthStirng += Math.floor(contentLength / 100 % 10).toString();
		lengthStirng += Math.floor(contentLength / 10 % 10).toString();
		lengthStirng += Number(contentLength % 10).toString();
	}
	
	packet.write("MA", define.HEADER_DESTINATION_START_OFFSET, 16, 'binary');
	packet.write("GP", define.HEADER_SOURCE_START_OFFSET, 16, 'binary');
	packet.write(messageType.toString(), define.HEADER_TYPE_START_OFFSET, 4, 'binary');
//	packet.write(null, define.HEADER_RESERVED_START_OFFSET, 8, 'binary');
	packet.write(lengthStirng || "0000", define.HEADER_LENGTH_START_OFFSET, 4, 'binary');
	
	lengthStirng = null;
    
	return packet;
};





encode.encodeContent = function(packet, messageType, content) {
	
	var offset = define.DEFAULT_HEADER_OFFSET; 
	
	switch(messageType){
	
		/*
			1001 - AUTHENTICATION
		 	admin Auth 를 요청
			
			DM_ADMIN_ID		0x81	현재 아이디
			DM_ADMIN_PASSWD	0x82	현재 비밀번호

		*/
		case define.AUTHENTICATION :
			offset = encode.TLV_String(packet, define.DM_ADMIN_ID, content.DM_ADMIN_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_PASSWD, content.DM_ADMIN_PASSWD, offset);
			break;
	
		
		
		/*
			1002 - CHANGE_AUTH
		 	admin ID PASSWD 변경요청
		 	
			DM_ADMIN_ID			0x81	현재 아이디
			DM_ADMIN_PASSWD		0x82	현재 비밀번호
			DM_ADMIN_NEW_ID		0x83	변경 할 아이디
			DM_ADMIN_NEW_PASSWD	0x84	변경 할 비밀번호

		*/
		case define.CHANGE_AUTH :
			offset = encode.TLV_String(packet, define.DM_ADMIN_ID, content.DM_ADMIN_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_PASSWD, content.DM_ADMIN_PASSWD, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_NEW_ID, content.DM_ADMIN_NEW_ID, offset);
			offset = encode.TLV_String(packet, define.DM_ADMIN_NEW_PASSWD, content.DM_ADMIN_NEW_PASSWD, offset);			
			break;
			
			
		/*
			1009 - UNREGISTER_DEVICE
			Device or Account unRegistration
			
			DM_UNREGI_TYPE			0x05	Unregistration type, 0x0001 DM_ACCOUNT, 0x0002 DM_DEVICE
		*/
		case define.UNREGISTER_DEVICE :
			offset = encode.TLV_Short(packet, define.DM_UNREGI_TYPE, content.DM_UNREGI_TYPE, offset);
			break;
			
	
		/*
			1010 - Get and Set extraInfo

			DM_SERVER_URL			0xA0 TP Server URL
			DM_MW_CURRENT_VER		0xA1 Middleware current version (receive only)
			DM_MW_LATEST_VER		0xA2 Middleware latest version (receive only)
			DM_TRACE_STATUS			0xA3 Trace status
			DM_TIMEZONE				0xA4 Log timezone
			DM_SET_TIME				0xA5 Device time
			DM_TIME_SYNC			0xA6 NTP Server sync(송신 전용)			
			
		*/
		case define.EXTRA_INFO :
		
			
			if(content.DM_SERVER_URL != undefined && content.DM_SERVER_URL != ""){
				
				offset = encode.TLV_String(packet, define.DM_SERVER_URL, content.DM_SERVER_URL, offset);
				
			}else if(content.DM_TRACE_STATUS != undefined && content.DM_TRACE_STATUS != ""){

				offset = encode.TLV_Short(packet, define.DM_TRACE_STATUS, content.DM_TRACE_STATUS, offset);
				
			}else if(content.DM_TIMEZONE != undefined && content.DM_TIMEZONE != ""){

				offset = encode.TLV_String(packet, define.DM_TIMEZONE, String(content.DM_TIMEZONE), offset);
				
			}else if(content.DM_SET_TIME != undefined && content.DM_SET_TIME != ""){

				offset = encode.TLV_String(packet, define.DM_SET_TIME, String(content.DM_SET_TIME), offset);
				
			}else if(content.DM_TIME_SYNC != undefined && content.DM_TIME_SYNC != ""){

				offset = encode.TLV_String(packet, define.DM_TIME_SYNC, String(content.DM_TIME_SYNC), offset);
				
			}else{
				throw "No Content - It should have 1 content";
			}
			
			break;
			

		/*
			1012 - IV
		 	IV receive confirmation
			
			DM_RESULT		0x01	Result status

		*/
		case define.IV :
			offset = encode.TLV_Short(packet, define.DM_RESULT, content.DM_RESULT, offset);
			
			break;	
			

			
		/*
			1022 - GET_DEVICE_SENSOR
		 	해당 디바이스에 연결된 센서정보를 요청
		 	
		 	1024 - GET_ALL_DEVICE_SENSOR_STATUS
		 	해당 디바이스의 센서의 센서상태 및 데이터를 요청
		 	
			DM_DEVICE_ID	0x42	디바이스 ID

		*/			
		case define.GET_DEVICE_SENSOR:
		case define.GET_ALL_DEVICE_SENSOR_STATUS:
		
			offset = encode.TLV_String(packet, define.DM_DEVICE_ID, content.DM_DEVICE_ID, offset);
			
			if(content.DM_SENSOR_ARRAY != undefined && content.DM_SENSOR_ARRAY != ""){
				offset = encode.TLV_String(packet, define.DM_SENSOR_ARRAY, content.DM_SENSOR_ARRAY, offset);
			}			

			break;
			
			
			
			
		/*
			1023 - GET_DEVICE_SENSOR_STATUS
		 	자기 장치에 연결된 디바이스 및 센서상태정보를 요청
			
			DM_DEVICE_ID	0x42	디바이스 ID
			DM_SENSOR_ID	0x43	센서 ID
			DM_SENSOR_NAME	0x44	센서이름
			DM_SENSOR_TYPE	0x45	센서타입
	
		*/
		case define.GET_DEVICE_SENSOR_STATUS :
			offset = encode.TLV_String(packet, define.DM_DEVICE_ID, content.DM_DEVICE_ID, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_ID, content.DM_SENSOR_ID, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_NAME, content.DM_SENSOR_NAME, offset);
			offset = encode.TLV_String(packet, define.DM_SENSOR_TYPE, content.DM_SENSOR_TYPE, offset);
			break;
		
			
		/*
			1045 - Account
			Login to MA with ThingPlug ID and Ukey

			DM_IOT_TP_ID	0x2C	ThingPlug ID
			DM_IOT_UKEY		0x27	ThingPlug Ukey			
			
		*/
		case define.ACCOUNT :
			offset = encode.TLV_String(packet, define.DM_IOT_TP_ID, content.DM_IOT_TP_ID, offset);
			offset = encode.TLV_String(packet, define.DM_IOT_UKEY, content.DM_IOT_UKEY, offset);
			break;
			
			
		/*
			1041 - REGISTER_DEVICE
		 	자기장치를 ThingPlug에 등록한다
		 	
			DM_IOT_PROTOCOL_TYPE	0x21	IOT Protocol 타입(“oneM2M” or “GMMP”
			DM_IOT_DEVICE_NAME		0x22	장치이름
			DM_IOT_PASS_CODE		0x23	디바이스 패스코드
			DM_IOT_SP_USE_FLAG		0x26	SKT 서비스플랫폼 사용여부
			DM_IOT_UKEY				0x27	UKEY
			DM_IOT_SERVICE_ID		0x28	서비스ID
			DM_IOT_AUTH_ID			0x29	인증ID(MAC Address or ISDN)
			DM_IOT_MANUFACTURE_ID	0x2A	제조사ID
			DM_IOT_SERVER_PORT		0x2B	서비스ID 에 할당된 접속 port

		*/
		case define.REGISTER_DEVICE :
			offset = encode.TLV_String(packet, define.DM_IOT_PROTOCOL_TYPE, content.DM_IOT_PROTOCOL_TYPE, offset);
			offset = encode.TLV_String(packet, define.DM_IOT_SERVICE_ID, content.DM_IOT_SERVICE_ID, offset);
			offset = encode.TLV_String(packet, define.DM_IOT_DEVICE_NAME, content.DM_IOT_DEVICE_NAME, offset);
			offset = encode.TLV_String(packet, define.DM_IOT_TP_ID, content.DM_IOT_TP_ID, offset);
			offset = encode.TLV_String(packet, define.DM_IOT_PASS_CODE, content.DM_IOT_PASS_CODE, offset);
			// offset = encode.TLV_String(packet, define.DM_SERVER_URL, content.DM_SERVER_URL, offset);
			break;

			
		/*
			1044 - SET_INTERVAL
			Sensor 정보 수집주기 및 Sensor 정보 ThingPlug 서버 등록 주기 정보를 요청
			DM_SENSOR_GATHER_INTERVAL			0x72	센서정보수집주기
			DM_SENSOR_SERVER_UPDATE_INTERVAL	0x73	센서정보서버 UDPATE주기
		*/
		case define.SET_INTERVAL :
			offset = encode.TLV_Integer(packet, define.DM_SENSOR_GATHER_INTERVAL, content.DM_SENSOR_GATHER_INTERVAL, offset);
			offset = encode.TLV_Integer(packet, define.DM_SENSOR_SERVER_UPDATE_INTERVAL, content.DM_SENSOR_SERVER_UPDATE_INTERVAL, offset);
			break;
			
			
		/*
			1062 - UPDATE_LOG
			로그정보 업데이트시 이를 MA에 전달한다
		 	
			DM_LOG_TYPE			0x61	요청로그타입
			DM_LOG_LEVEL		0x62	로그레벨
			DM_LOG_DEVICE_ID	0x66	로그디바이스ID
			DM_LOG_SENSOR_ID	0x67	로그SENSORID
			DM_LOG_DATA			0x64	로그데이터

		*/	
		case define.UPDATE_LOG :
			offset = encode.TLV_Integer(packet, define.DM_LOG_TYPE, content.DM_LOG_TYPE, offset);
			offset = encode.TLV_Integer(packet, define.DM_LOG_LEVEL, content.DM_LOG_LEVEL, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_DEVICE_ID, content.DM_LOG_DEVICE_ID, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_SENSOR_ID, content.DM_LOG_SENSOR_ID, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_DATA, content.DM_LOG_DATA, offset);
			break;
	
		
		/*
			1063 - GET_SYSTEM_LOG
		 	로그정보를 요청한다. (미들웨어와 ThingPlug연동로그 및 미들웨어와 센서 연동로그 포함)
			
			DM_LOG_TYPE		0x61	요청로그타입
			DM_LOG_NEXT_KEY	0x63	Next Key
			DM_LOG_COUNT	0x65	요청COUNT
	
		*/
		case define.GET_SYSTEM_LOG :
			offset = encode.TLV_Integer(packet, define.DM_LOG_TYPE, content.DM_LOG_TYPE, offset);
			offset = encode.TLV_String(packet, define.DM_LOG_NEXT_KEY, content.DM_LOG_NEXT_KEY, offset);
			offset = encode.TLV_Integer(packet, define.DM_LOG_COUNT, content.DM_LOG_COUNT, offset);
			break;
		

		default : 
			
			break;
	}

	
	// encryption after binary buffering
	
	var hexNum = Math.ceil((offset - 48) / 16)*16;
	var tempBuffer = new Buffer(hexNum);
	
	// console.log("encode.js encryption key " + define.encrptionKey);
	// console.log("encode.js encryption IV " + define.encrptionIV);
	
	tempBuffer.fill(0x00);
	packet.copy(tempBuffer, 0, 48, offset);

		var cipher = crypto.createCipheriv("aes-128-cbc", define.encrptionKey, define.encrptionIV);
		cipher.setAutoPadding(false);
		
		var ciphertext = cipher.update(tempBuffer);
		ciphertext = Buffer.concat([ciphertext, cipher.final()]);
		
		ciphertext.copy(packet, 48, 0);		
	
	return offset;
	
}



encode.TLV_String = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(description.length, offset);
	offset += 2;
	// Value nByte
	packet.write(description, offset, offset + description.length, 'binary');
	offset += description.length;
	return offset;
}

encode.TLV_Double = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0008, offset);
	offset += 2;
	// Value nByte
	packet.writeDoubleLE(description, offset);
	offset += 8;
	return offset;
}

encode.TLV_Integer = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0004, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt32LE(description, offset);
	offset += 4;
	return offset;
}

encode.TLV_Short = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0002, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt16LE(description, offset);
	offset += 2;
	return offset;
}

encode.TLV_Char = function(packet, contentType, description, offset){
	
	// Type 1Byte
	packet.writeUInt8(contentType, offset);
	offset += 1;
	// Length 2Byte
	packet.writeUInt16LE(0X0001, offset);
	offset += 2;
	// Value nByte
	packet.writeUInt8(description, offset);
	offset += 1;
	
	return offset;
}
