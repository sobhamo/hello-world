/**
 *
 * 인트로 > 간편설정 > step01
 *
 */

(function () {

	var isNext = false;
	var DM_IOT_DEV_REG_STATE;

	$(function () {

		init();

		// 다음버튼
		$(".bt_next").click(function (e) {
			console.log("isNext : ",  isNext);
			if (!isNext) {
				e.preventDefault();
				alert(__("네트워크 연결상태를 확인하세요"));
			}

			console.log("IPC.DM_REGISTERED : ",  IPC.DM_REGISTERED);
			if (DM_IOT_DEV_REG_STATE == IPC.DM_REGISTERED) {
				e.preventDefault();
				console.log(__("이미 등록 되어있는 디바이스 입니다"));
				alert(__("이미 등록 되어있는 디바이스 입니다"));
				setTimeout(function () {
					window.location.href = "/Dashboard/Dashboard";
				}, 1000);
			}
		});

		// Thingplug 회원가입
		$(".bt_join").click(function (e) {

			e.preventDefault();

			window.open("thjoin", "IoTPortalPopup");
			$("#IoTPortalForm").submit();

		});
	});

	// 페이지 초기화
	var init = function () {

		// 시스템 정보
		ipc.send("getSystemInfo", false, function (res) {

			// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}

			var DM_MAC_ADDRESS = res.DM_MAC_ADDRESS.replaceAll(":", "") + " (" + res.DM_MAC_ADDRESS + ")";
			$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
			$("#DM_MAC_ADDRESS").text(DM_MAC_ADDRESS);
			$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);
			$("#DM_CPU_TYPE").text(res.DM_CPU_TYPE);
			$("#DM_RAM_TYPE").text(res.DM_RAM_TYPE);
			$("#DM_BATTERY_TYPE").text(res.DM_BATTERY_TYPE);

			isNext = true;
		});

		// Thingplug 상태
		ipc.send("getThingStatus", false, function (res) {

			// {DM_RESULT: 1, DM_IOT_DEV_REG_STATE: 2, DM_IOT_THING_STATUS: 1}
			DM_IOT_DEV_REG_STATE = res.DM_IOT_DEV_REG_STATE;
		});
	};
})();