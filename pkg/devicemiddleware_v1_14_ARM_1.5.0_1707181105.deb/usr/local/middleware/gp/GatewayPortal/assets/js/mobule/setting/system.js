
/** 
 *
 * 환경설정 > 시스템 설정
 *
 */

(function () {

	var option = {
		modalClose : false, 
		positionStyle : "fixed", 
		follow : [ true, true ]
	}
	
	var ONLY_NUMBER_INPUT = true;
	
	$(function () {

		init();
		
		
		// ThingPlug URL update
		$(".bt_tpURL").click(function (e) {
			
			e.preventDefault();
			
			if ($("#tpURL").Empty(__("변경할 ThingPlug 주소를 입력하여 주세요"))) return false;
			var tpURL = $("#tpURL").val();
			var params = new Params();
			params.put("DM_SERVER_URL", tpURL);	

			ipc.start(1);			
			ipc.send("extraInfo", params, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료"));
				}else{
					alert(__("적용 실패"));
				}
			});
		});
		
		
		// Log timezone update
		$("#log_timezone_bt").click(function (e) {
			e.preventDefault();
			var user_timezone = $("#user-timezone option:selected").val();
			var params = new Params();
			params.put("DM_TIMEZONE", user_timezone);		

			ipc.start(1);			
			ipc.send("extraInfo", params, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료"));
				}else{
					alert(__("적용 실패"));
				}
			});
		});	

		// Device time update
		$("#device_time_bt").click(function (e) {
			e.preventDefault();

			
			var sendTime = new Date();
			sendTime.setHours($("#set_hour option:selected").val());
			sendTime.setMinutes($("#set_minute option:selected").val());
			sendTime.setSeconds($("#set_second option:selected").val());
			
			var chaTime = sendTime.getTime().toString().substr(0,10);
			
			var params = new Params();
			params.put("DM_SET_TIME", chaTime);

			ipc.start(1);
			ipc.send("extraInfo", params, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료"));
				}else{
					alert(__("적용 실패"));
				}
			});
		});	

		// Time Server Sync
		$("#ntp_sync_bt").click(function (e) {
			e.preventDefault();
			
			var params = new Params();
			params.put("DM_TIME_SYNC", 1);

			ipc.start(1);
			ipc.send("extraInfo", params, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					window.location.reload();
				}else{
					alert(__("적용 실패"));
				}
			});
		});			

		
		// 시스템 재실행
		$(".btRestart").click(function (e) {
			e.preventDefault();
//			Exec("restart");
			// 시스템 정보
			ipc.start(1);
			ipc.send("restart", false, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료. 15초 후에 다시 로그인하십시오."));
					setTimeout(function() {window.location.href = "/Logout";}, 2000);
				}else{
					alert(__("적용 실패"));
				}
			});
		});

		// 시스템 초기화
		$(".btReset").click(function (e) {
			e.preventDefault();
//			Exec("reset");
			// 시스템 정보
			ipc.start(1);
			ipc.send("reset", false, function (res) {
				ipc.end();
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료"));
				}else{
					alert(__("적용 실패"));
				}
			});
		});

		
		$(".bt_config").click(function (e) {
			
			e.preventDefault();

			if ($("#config_change").Empty(__("변경할 파일 이름을 입력하여 주세요"))) return false;		
			var DM_SENSOR_CONFIG_FILENAME = $("#config_change").val();
			var params = new Params();
			params.put("DM_SENSOR_CONFIG_FILENAME", DM_SENSOR_CONFIG_FILENAME);
			
			// config 파일 변경
			ipc.send("changeSensorConfigFile", params, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("적용 완료"));
				}
			});
		});
		
		$("#config_change").on("blur",function (e) { ONLY_NUMBER_INPUT = true });
		$("#config_change").on("focus",function (e) { ONLY_NUMBER_INPUT = false });
		

		// 키 입력, 숫자만 가능하도록
		$(".interval_set input").keydown(inputNumber);

		// 설정 저장
		$(".bt_apply").click(function (e) {

			e.preventDefault();

			// GMMP 는 저장 할수 없도록..
			

			var DM_SENSOR_GATHER_INTERVAL = $("#DM_SENSOR_GATHER_INTERVAL").val();
			var DM_SENSOR_SERVER_UPDATE_INTERVAL = $("#DM_SENSOR_SERVER_UPDATE_INTERVAL").val();

			// 숫자인지
			if (isNaN(DM_SENSOR_GATHER_INTERVAL)) {
				$("#DM_SENSOR_GATHER_INTERVAL").focus();
				alert(__("숫자만 입력하세요"));
				return;
			}
			if (isNaN(DM_SENSOR_SERVER_UPDATE_INTERVAL)) {
				$("#DM_SENSOR_SERVER_UPDATE_INTERVAL").focus();
				alert(__("숫자만 입력하세요"));
				return;
			}

			DM_SENSOR_GATHER_INTERVAL = parseInt(DM_SENSOR_GATHER_INTERVAL);
			DM_SENSOR_SERVER_UPDATE_INTERVAL = parseInt(DM_SENSOR_SERVER_UPDATE_INTERVAL);

			// min, max
			if (DM_SENSOR_GATHER_INTERVAL < 1) {
				$("#DM_SENSOR_GATHER_INTERVAL").focus();
				alert(__("최소 1초 입력하세요"));
				return;
			}
			if (DM_SENSOR_GATHER_INTERVAL > 3600) {
				$("#DM_SENSOR_GATHER_INTERVAL").focus();
				alert(__("최대 3600초 입력하세요"));
				return;
			}
			if (DM_SENSOR_SERVER_UPDATE_INTERVAL < 10) {
				$("#DM_SENSOR_SERVER_UPDATE_INTERVAL").focus();
				alert(__("최소 10초 입력하세요"));
				return;
			}
			if (DM_SENSOR_SERVER_UPDATE_INTERVAL > 3600) {
				$("#DM_SENSOR_SERVER_UPDATE_INTERVAL").focus();
				alert(__("최대 3600초 입력하세요"));
				return;
			}

			// 수집이 작으면 안됨
			if (DM_SENSOR_GATHER_INTERVAL > DM_SENSOR_SERVER_UPDATE_INTERVAL) {
				alert(__("수집주기는 등록주기보다 빨라야 합니다"));
				return;
			}

			var params = new Params();
			params.put("DM_SENSOR_GATHER_INTERVAL", DM_SENSOR_GATHER_INTERVAL);
			params.put("DM_SENSOR_SERVER_UPDATE_INTERVAL", DM_SENSOR_SERVER_UPDATE_INTERVAL);

			ipc.send("setInterval", params, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					alert(__("저장되었습니다"));
				} else {
					alert(__("저장에 실패하였습니다"));
				}
			});
		});
	});

	// 페이지 초기화
	var init = function () {

		// oneM2M일때만 보여주기
		$(".interval_set").hide();
		
		// 시스템 정보
		ipc.send("getInterval", false, function (res) {

			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				$("#DM_SENSOR_GATHER_INTERVAL").val(res.DM_SENSOR_GATHER_INTERVAL);
				$("#DM_SENSOR_SERVER_UPDATE_INTERVAL").val(res.DM_SENSOR_SERVER_UPDATE_INTERVAL);
			}
		});
		
		
		// 시스템 정보
		ipc.send("getThingStatus", false, function (res) {
			if (res.DM_IOT_PROTOCOL_TYPE && res.DM_IOT_PROTOCOL_TYPE != "GMMP") {
				$(".interval_set").show();
			}
		});
		
		// Get extraInfo
		ipc.send("extraInfo", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

				var timezone = res.DM_TIMEZONE;
				var time10no = Number(res.DM_SET_TIME) * 1000;
				var tempTime = new Date(time10no);
				var currentHour = tempTime.getHours();
				var currentMinute = tempTime.getMinutes();
				var currentSecond = tempTime.getSeconds();
				$('#user-timezone option').removeAttr('selected').filter('[value="' + timezone + '"]').attr('selected', 'selected').trigger("change");
				$('#set_hour option').removeAttr('selected').filter('[value="' + currentHour + '"]').attr('selected', 'selected').trigger("change");
				$('#set_minute option').removeAttr('selected').filter('[value="' + currentMinute + '"]').attr('selected', 'selected').trigger("change");
				$('#set_second option').removeAttr('selected').filter('[value="' + currentSecond + '"]').attr('selected', 'selected').trigger("change");
				$('#tpURL').val(res.DM_SERVER_URL);
		
			}
		});		
		
	}

	// 숫자만 입력
	var inputNumber = function () {
		var keyCode = event.which ? event.which : event.keyCode;

		if(!ONLY_NUMBER_INPUT) return true;
		
		if ((keyCode == 8								// 백스페이스
			|| keyCode == 46								// del
			|| keyCode == 9								// tab
			|| keyCode == 37								// left
			|| keyCode == 39								// right
			|| keyCode == 35							// end
			|| keyCode == 36							// home
			|| keyCode == 116								// F5
			|| (keyCode >= 48 && keyCode <= 57)			// 상단 숫자
			|| (keyCode >= 96 && keyCode <= 105)		// 키패드
			|| (event.ctrlKey && keyCode == 67)				// Ctrl+c
			|| (event.ctrlKey && keyCode == 86)				// Ctrl+v
			|| (event.ctrlKey && keyCode == 90)				// Ctrl+z
		)) return true; 

		return false;
	}

	// 실행
	var Exec = function (t) {
		
		$("#loading span").text(t == "restart" ? __("재실행") : __("초기화"));
		$("#loading").bPopup(option);
		
		ipc.send(t, false, function (res) {
			setTimeout(function () {
				$("#loading").bPopup().close();
			}, 500);
		});
	}

})();
