
/**
 *
 * 연결조회 > 센서
 *
 */

(function () {

	var BASE_MAIN_DOM = false;
	var BASE_DOM = false;
	
	var sensorTypeDom, sensorTypeDomLeft, sensorTypeDomHeight;	

	
	$(function () {

		BASE_MAIN_DOM = $(".article.sensorControl").clone();
		BASE_ADD_DOM = $(".sensor_add tr:first").clone();
		$(".article.sensorControl").remove();
		
		// onClick add button
		// $("document").on("click", ".bt_add", function (e) {

			// e.preventDefault();
			
			// console.log("happy");
			
			// var codeBlock = $(this).parents(".sensorControl");
			// var addBlock = $(this).parents(".sensor_add");
			// console.log(addBlock);
			// console.log(BASE_ADD_DOM);
			// var addTr= codeBlock.find(".sensor_add tr").clone();
			// codeBlock.find(".sensor_list").append(addTr);
			// codeBlock.find(".sensor_add tr").remove();
			// addBlock.append(BASE_ADD_DOM);					
					
		// });
		
		connection_sensor.init();
			
		// 로그 히스토리 
		setTimeout(function () {
			_history.init(_history.All, false);
		}, 1000);

	});
	
	window.connection_sensor = {
			
		index : 0,
		init : function () {
			var that = this;
			// 센서 리스트
			ipc.send("getDevice", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					that.getAllDeviceSensorStatus(res.DM_DEVICE_ID);
				}
			});
		},
		
		getAllDeviceSensorStatus : function(DEVICE_LIST){
			
			var that = this;
			var endCheckIndex = this.index;
			
			if(this.index < DEVICE_LIST.length){
				
				var params = new Params();
				params.put("DM_DEVICE_ID", DEVICE_LIST[this.index]);
				
				var deviceName = DEVICE_LIST[this.index]
				var main_dom = BASE_MAIN_DOM.clone();
				main_dom.addClass(deviceName);
				main_dom.find(".desc").text(deviceName);
				
				BASE_DOM = main_dom.find(".sensor_list tr:first");
				main_dom.find(".sensor_list tr:first").remove();	
				
				
				ipc.send("getAllDeviceSensorStatus", params, function (res) {

					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

						for (var q in res.DM_SENSOR_ARRAY) {


							var sensor = res.DM_SENSOR_ARRAY[q];
							var tr = BASE_DOM.clone();
							var DM_SENSOR_STATUS = (sensor.DM_SENSOR_STATUS == "N/A") ? sensor.DM_SENSOR_STATUS : JSON.parse(sensor.DM_SENSOR_STATUS);

							tr.find("[name='sensor_type']").val(sensor.DM_SENSOR_TYPE);
							tr.find("[name='sensor_index']").val(sensor.DM_SENSOR_ID);
							tr.find("[name='sensor_id']").text(sensor.DM_SENSOR_TYPE+"_"+sensor.DM_SENSOR_ID);
							tr.find("[name='sensor_driver']").val(sensor.DM_SENSOR_NAME);
							tr.find("[name='sensor_interval']").val(sensor.DM_SENSOR_CYCLE);
							tr.find("[name='sensor_datatype'] option").removeAttr('selected').filter('[value="' + sensor.DM_SENSOR_OPERATION_TYPE + '"]').prop('selected', true);
							tr.find("[name='sensor_maxinterval']").val(sensor.DM_SENSOR_CHECK_CYCLE);
							tr.find("[name='sensor_category'] option").removeAttr('selected').filter('[value="' + sensor.DM_SENSOR_CONTROL_TYPE + '"]').prop('selected', true);


							if (DM_SENSOR_STATUS != "N/A" && DM_SENSOR_STATUS.status == "on") {
								tr.find("[name='sensor_status']").text("Online");
							}else{
								tr.find("[name='sensor_status']").text("Offline");								
							}

							main_dom.find(".sensor_list").append(tr);
							
							// 로그쪽 장비 셀렉트박스 
							$("#sel_01").append('<option value="' + sensor.DM_DEVICE_ID + "_" +sensor.DM_SENSOR_ID + '">'  + sensor.DM_DEVICE_ID + " > " +sensor.DM_SENSOR_TYPE + '</option>');
							
						}
						
						main_dom.insertBefore(".article.errorTable");
						// main_dom.trigger("refresh");
						
						
						// onClick add button
						main_dom.on("click", ".bt_add", function (e) {

							e.preventDefault();
							
							// console.log("happy");
							
							var codeBlock = $(this).parents(".sensorControl");
							var addBlock = $(this).parents(".sensor_add");
							var newTr = BASE_DOM.clone();

							// var addTr= codeBlock.find(".sensor_add tr").clone();
							
							if (addBlock.find("[name='sensor_type']").Empty(__("Please enter type"))) return;
							if (addBlock.find("[name='sensor_index']").Empty(__("Please enter index"))) return;
							if (addBlock.find("[name='sensor_driver']").Empty(__("Please enter driver"))) return;
							if (addBlock.find("[name='sensor_interval']").Empty(__("Please enter interval"))) return;
							if (addBlock.find("[name='sensor_datatype']").Empty(__("Please select datatype"))) return;
							if (addBlock.find("[name='sensor_maxinterval']").Empty(__("Please enter maxinterval"))) return;
							if (addBlock.find("[name='sensor_category']").Empty(__("Please select category"))) return;


							newTr.find("[name='sensor_type']").val(addBlock.find("[name='sensor_type']").val());
							newTr.find("[name='sensor_index']").val(addBlock.find("[name='sensor_index']").val());
							newTr.find("[name='sensor_id']").text(newTr.find("[name='sensor_type']").val() + '_' + newTr.find("[name='sensor_index']").val());
							newTr.find("[name='sensor_driver']").val(addBlock.find("[name='sensor_driver']").val());
							newTr.find("[name='sensor_interval']").val(addBlock.find("[name='sensor_interval']").val());
							newTr.find("[name='sensor_datatype']").val(addBlock.find("[name='sensor_datatype']").val());
							newTr.find("[name='sensor_maxinterval']").val(addBlock.find("[name='sensor_maxinterval']").val());
							newTr.find("[name='sensor_category']").val(addBlock.find("[name='sensor_category']").val());
							
							codeBlock.find(".sensor_list").append(newTr);
							
							addBlock.find("[name='sensor_type']").val("");
							addBlock.find("[name='sensor_index']").val("");
							addBlock.find("[name='sensor_driver']").val("");
							addBlock.find("[name='sensor_interval']").val("");
							addBlock.find("[name='sensor_datatype']").prop('selectedIndex', 0);
							addBlock.find("[name='sensor_maxinterval']").val("");
							addBlock.find("[name='sensor_category']").prop('selectedIndex', 0);							

							codeBlock.trigger("refresh");		
							
						// onClick sensor_type box
						}).on("click", "[name='sensor_type']", function (e) {

							e.preventDefault();
							
					
							sensorTypeDom = $(this);
							sensorTypeDomHeight = $(this).position().top;
							sensorTypeDomLeft = $(this).position().left;
							
							var codeBlock = $(this).parents(".sensorControl");
							var typeDiv = codeBlock.find(".typeList");
							
							typeDiv.css({"top": sensorTypeDomHeight, "left": sensorTypeDomLeft + 100 });
							typeDiv.removeClass("dOff");

						// onClick sensor_type select lablel	
						}).on("click", ".typeList label", function (e) {

							e.preventDefault();
							
							var typeValue = $(this).text();
							
							sensorTypeDom.val(typeValue);
							$(this).parents(".typeList").addClass("dOff");

						// onClick delete button						
						}).on("click", ".bt_delete", function (e) {

							e.preventDefault();
							
							
							var codeBlock = $(this).parents(".sensorControl");
							$(this).parents("tr").remove();

							codeBlock.trigger("refresh");		

						// onClick apply button	
						}).on("click", ".bt_apply", function (e) {

							e.preventDefault();
							
							
							var i = 0;
							var codeBlock = $(this).parents(".sensorControl");	
							var trLength = codeBlock.find(".sensor_list tr").length;
							var sensorConfig = "";
							var ID_array = [];
							
							
							for (i = 0; i < trLength ; i++) { 

								if (codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_type']").Empty(__("Please enter value"))) return;
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_type']").val().trim() + ",";
								
								if (codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_index']").Empty(__("Please enter value"))) return;
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_index']").val().trim() + ",";
								
								if (codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_driver']").Empty(__("Please enter value"))) return;
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_driver']").val().trim() + ",";
								
								if (codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_interval']").Empty(__("Please enter value"))) return;
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_interval']").val().trim() + ",";
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_datatype']").val().trim() + ",";
								
								if (codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_maxinterval']").Empty(__("Please enter value"))) return;
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_maxinterval']").val().trim() + ",";
								sensorConfig = sensorConfig + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_category']").val().trim() + ";";
								
								ID_array[i] = codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_type']").val().trim() + codeBlock.find(".sensor_list tr").eq(i).find("[name='sensor_index']").val().trim()
								
							}
							
							sensorConfig = sensorConfig.substring(0, sensorConfig.length-1);
			
							ID_array.sort();
							for ( var i = 1; i < trLength; i++ ){
								if(ID_array[i-1] == ID_array[i]) {
									alert(__("ID 중복. Index 수정 필요"));
									return false;
								}
							}
							
							// console.log(sensorConfig);
							
							var params = new Params();
							params.put("DM_DEVICE_ID", deviceName);
							params.put("DM_SENSOR_ARRAY", sensorConfig);
							
							console.log(params)

							// 기존에 있는 정보 리셋
							ipc.send("reset", false, function (res) {
								if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
									// 센서 정보 세팅
									ipc.send("getAllDeviceSensorStatus", params, function (res) {
										if (res.DM_RESULT == IPC.DM_RESULT_SENSOR_CHANGED) {
											alert(__("적용 완료. 15초 후에 다시 로그인하십시오."));
											setTimeout(function() {window.location.href = "/Logout";}, 2000);
										} else {
											alert(__("적용 실패"));
										}
									});
								}else{
									ipc.end();
									alert(__("적용 실패"));
								}
							});

						// when input box changed to null value	
						}).on("change", ".sensor_list input", function (e) {

							e.preventDefault();
							
							if ($(this).Empty(__("Please enter value"))) return;	
							
						}).on("keydown", "[name='sensor_index'], [name='sensor_interval'], [name='sensor_maxinterval']", inputNumber);
						
						
						that.getAllDeviceSensorStatus(DEVICE_LIST);
					}
				});
				
				this.index++;
				
			}
		}
		
	}
	
		// 숫자만 입력
	var inputNumber = function () {
		var keyCode = event.which ? event.which : event.keyCode;

		
		if ((keyCode == 8								// 백스페이스
			|| keyCode == 46								// del
			|| keyCode == 9								// tab
			|| keyCode == 37								// left
			|| keyCode == 39								// right
			|| keyCode == 35							// end
			|| keyCode == 36							// home
			|| keyCode == 116								// F5
			|| (keyCode >= 48 && keyCode <= 57)			// 상단 숫자
			|| (keyCode >= 96 && keyCode <= 105)		// 키패드
			|| (event.ctrlKey && keyCode == 67)				// Ctrl+c
			|| (event.ctrlKey && keyCode == 86)				// Ctrl+v
			|| (event.ctrlKey && keyCode == 90)				// Ctrl+z
		)) return true; 

		return false;
	}

})();