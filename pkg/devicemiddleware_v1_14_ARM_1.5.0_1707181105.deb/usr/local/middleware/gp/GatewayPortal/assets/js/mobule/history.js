
/**
 *
 * 히스토리
 *
 */

 (function () {

	var DM_LOG_NEXT_KEY = "0000";
	var DM_LOG_TYPE = 0;
	var params = new Params();
	var BASE_DOM = false;
	var SELECT_DEVICE = "all";
	var SELECT_LOGGER = "All";
	var history_timer;
	var loading = false;
	var TIMEZONE = 900;

	window._history = {

		All : 0,
		GatewayPortal : 1,
		Thingplug : 2,
		Sensor : 3,

		init : function (t, _loading) {

			loading = _loading;
			if (loading) ipc.start();

			var that = this;
			
			// Get extraInfo
			
			ipc.send("extraInfo", false, function (res) {
			
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

					TIMEZONE = res.DM_TIMEZONE;
			
				}

				if (res.DM_TRACE_STATUS == 2) {

					$("input[name='rdo_Log']").eq(0).parent().removeClass("on");
					$("input[name='rdo_Log']").eq(0).prop("checked", false);				
					$("input[name='rdo_Log']").eq(1).parent().addClass("on");
					$("input[name='rdo_Log']").eq(1).prop("checked", true);	
					
					$.cookie("DM_TRACE_STATUS", null, { path: "/", expires : -1 });
					$.cookie("DM_TRACE_STATUS", 2, { path: "/", secure : false });
			
				}else{

					$("input[name='rdo_Log']").eq(0).parent().addClass("on");
					$("input[name='rdo_Log']").eq(0).prop("checked", true);				
					$("input[name='rdo_Log']").eq(1).parent().removeClass("on");
					$("input[name='rdo_Log']").eq(1).prop("checked", false);

					$.cookie("DM_TRACE_STATUS", null, { path: "/", expires : -1 });
					$.cookie("DM_TRACE_STATUS", 1, { path: "/", secure : false });					
					
				}
			
			});	
			

			// 히스토리 테이블 스크롤 디텍팅
			$(".scrolls").on("scroll", function() {
				if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
					that.load_data();
				}
			});

			// refresh 버튼
			$(".totalHistoryList a.bt_orange").click(function (e) {
				e.preventDefault();
				$(".log_list").empty();
				DM_LOG_NEXT_KEY = "0000";
				that.load_data();
			});

			// reset 버튼
			$(".totalHistoryList a.bt_black").click(function (e) {
				e.preventDefault();
				ipc.send("logReset", false, function(res){
					if(res.DM_RESULT == IPC.DM_RESULT_SUCCESS){
						$(".log_list").empty();
						DM_LOG_NEXT_KEY = "0000";
						that.load_data();	
					}
				});
			});

			// 엑셀 다운로드 버튼
			$(".bt_cbtn.bt_red").click(function (e) {
				e.preventDefault();

				var download_list = [];

				$(".log_list tr").each(function () {
					if ($(this).css("display") != "none") {
						download_list.push({
							"logTime" : $.trim($(this).find("td.logTime").text()),
							"logType" : $.trim($(this).find("td.logType").text()),
							"logLevel" : $.trim($(this).find("td.logLevel").text()),
							"logMsg" : $.trim($(this).find("td.logMsg").text())
						});
					}
				});

				var param = new Params();
				param.put("download_list" , download_list);

				var newForm = $("<form />", {
					"action" : "/Download",
					"method" : "post",
					"enctype" : "multipart/form-data"
				}).append($("<input />", {
					"name": "download_list",
					"value": JSON.stringify(param.serialize()),
					"type": "hidden"
				}));
				newForm.submit();
			});

			// log trace 버튼
			$("input[name='rdo_Log']").click(function (e) {
				var DM_TRACE_STATUS = IPC.DM_TRACE_ON;
				if ($(this).val() == "N") DM_TRACE_STATUS = IPC.DM_TRACE_OFF;

				$.cookie("DM_TRACE_STATUS", null, { path: "/", expires : -1 });
				$.cookie("DM_TRACE_STATUS", DM_TRACE_STATUS, { path: "/", secure : false });

				var params = new Params();
				params.put("DM_TRACE_STATUS", DM_TRACE_STATUS);

				console.log(params);
				ipc.send("extraInfo", params, function (res) {

					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
						alert(__("적용 완료"));
					}else{
						alert(__("적용 실패"));
					}
				});				
			
				// ipc.send("setTraceStatus", params);
			});

			// 장비명 선택
			$("#sel_01").change(function () {
				that.filter();
			});

			// 로그레벨 선택
			$("#sel_02").change(function () {
				that.filter();
			});

			// 초기 셋팅
			DM_LOG_TYPE = t ? t : this.All;
			DM_LOG_NEXT_KEY = "0000";

			// BASE DOM 처리
			this.BASE_DOM = $(".log_list tr:first").clone();
			$(".log_list tr:first").remove();

			params.put("DM_LOG_COUNT", Config.History.Count);

			this.start();
		},

		// 로그 필터
		filter : function () {
			
			
			var type_logger = $("#sel_01").val();
			var level_logger = $("#sel_02").val().toLowerCase();
			
			
			console.log("filter type_logger : " + type_logger + " ,  level_logger : " + level_logger);
			
			if (type_logger == "all" && level_logger == "all") {	// 모두 all
				
				console.log("모두 ALL");
				$(".log_list tr").show();
			} else {
				$(".log_list tr").hide();
				$(".log_list tr").each(function () {
					
					if(type_logger == "all"){
						if($(this).hasClass(level_logger)) $(this).show();
					}else if(level_logger == "all"){
						if($(this).hasClass(type_logger)) $(this).show();
					}else{
						if ($(this).hasClass(type_logger) && $(this).hasClass(level_logger)) $(this).show();
					}
					
				});
			}
		},

		// 센서 정보 요청 타이머 시작
		start : function () {
			this.load_data();
			//history_timer = setInterval(this.load_data, Config.Repeat.History);
		},

		load_data : function () {

			var that = this;

			// 타입
			//var _t = $("input[name='rdo_Type']:checked").val();
			//if (!_t || _t == _history.GatewayPortal || _t == _history.Thingplug) DM_LOG_TYPE = _history.All;
			//else if (_t == _history.Sensor) DM_LOG_TYPE = _history.Sensor;

			params.put("DM_LOG_TYPE", DM_LOG_TYPE);
			params.put("DM_LOG_NEXT_KEY", DM_LOG_NEXT_KEY);

			//ipc.dev = true;

			SELECT_DEVICE = $("#sel_01 option:selected").val();
			SELECT_LOGGER = $("#sel_02 option:selected").val();

			// 로그 히스토리
			ipc.send("getSystemLog", params, function (res) {

				if (loading) ipc.end();

				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

					DM_LOG_NEXT_KEY = res.DM_LOG_DATA.logNextKey;

					if (res.DM_LOG_DATA.logList && res.DM_LOG_DATA.logList.length > 0) {
						for (var p in res.DM_LOG_DATA.logList) {

							var item = res.DM_LOG_DATA.logList[p];

							var logType = item.logType;
							var logSubType = item.logSubType;
							var logLevel = item.logLevel.toLowerCase();
							var logTime = item.logTime;
							var logDeviceId = item.logDeviceId;
							var logSensorId = item.logSensorId;
							var logMsg = item.logMsg;
							
							var time10no = Number(logTime) * 1000 + Number(TIMEZONE) * 3600 * 1000 / 100;
							var tempTime = new Date(time10no);
							var timeText = tempTime.toISOString().substr(0, 19).replace("T", " ");
							

							var TR = _history.BASE_DOM.clone();

							TR.addClass(logLevel);
							TR.addClass(logType);
							
							if(logDeviceId && logSensorId) TR.addClass(logDeviceId + "_" + logSensorId);
							if (logSubType && logSubType != "(null)") TR.addClass(logSubType);
							TR.find("td.logType").text(logDeviceId ? logDeviceId : logType ? logType : logSubType);
							TR.find("td.logLevel span").text(logLevel);
							TR.find("td.logLevel img").attr("src", "/assets/images/icon/cir_" + logLevel + ".png");
							TR.find("td.logTime").text(tempTime.toISOString().substr(0, 19).replace("T", " "));
							TR.find("td.logMsg").text(logMsg);
							
							TR.hide();

							$(".log_list").append(TR);
						}
						that.filter();
					}
				}
			});
		}
	};

 })();