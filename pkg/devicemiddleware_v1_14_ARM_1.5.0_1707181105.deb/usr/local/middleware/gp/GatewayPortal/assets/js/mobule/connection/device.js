
/**
 *
 * 연결조회 > 디바이스
 *
 */

(function () {

	$(function () {

		// 센서
		connection_sensor.init();
		
		// 로그 히스토리 
		setTimeout(function () {
			
			_history.init(_history.All, false);
		}, 1000);
		
	});

	window.connection_sensor = {
		
		index : 0,
		init : function () {
			var that = this;
			// 센서 리스트
			ipc.send("getDevice", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					that.getAllDeviceSensorStatus(res.DM_DEVICE_ID);
				}
			});
			
			// 시스템 정보
			ipc.send("getSystemInfo", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
				}
			});

			// 네트웤크 정보
			ipc.send("getNetworkInfo", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					$("#DM_IP_ADDRESS").text(res.DM_IP_ADDRESS);
				}
			});

			// Thingplug 상태
			ipc.send("getThingStatus", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					if (res.DM_IOT_THING_STATUS == IPC.DM_THING_ONLINE) {
						$("#DM_IOT_THING_STATUS").text(__("ThingPlug와 정상적으로 연결 됨"));
					} else {
						$("#DM_IOT_THING_STATUS").text(__("ThingPlug와 연결이 되지 않음"));
					}
				}
			});

			// 구동시간 
			ipc.send("checkUptime", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					$("#DM_UPTIME").text(res.UPTIME);
				}
			});
		},
		
		getAllDeviceSensorStatus : function(DEVICE_LIST){
			
			var that = this;
			
			if(this.index < DEVICE_LIST.length){
				
				var params = new Params();
				params.put("DM_DEVICE_ID", DEVICE_LIST[this.index]);
				
				ipc.send("getAllDeviceSensorStatus", params, function (res) {
					
					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
						
						for (var q in res.DM_SENSOR_ARRAY) {

							var sensor = res.DM_SENSOR_ARRAY[q];
							
							// 로그쪽 장비 셀렉트박스 
							$("#sel_01").append('<option value="' + sensor.DM_DEVICE_ID + "_" +sensor.DM_SENSOR_ID + '">'  + sensor.DM_DEVICE_ID + " > " +sensor.DM_SENSOR_TYPE + '</option>');
							
						}
						that.getAllDeviceSensorStatus(DEVICE_LIST);
					}
				});
				
				this.index++;
			}
		}
		
	}

})();