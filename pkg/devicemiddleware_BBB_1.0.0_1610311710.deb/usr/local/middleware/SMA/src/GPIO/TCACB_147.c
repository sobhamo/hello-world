/**
 * @file TCACB_147.c
 *
 * @brief TCACB_147 Noise Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "TCACB_147.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */

#define FILE_PATH "/sys/class/gpio/gpio51/value"
#define ENABLE_GPIO_51 "echo 51 > /sys/class/gpio/export"
#define DATA_MAX_SIZE 2

static FILE *gTCACB_147Fp = NULL;


/*
 ****************************************
 * TCACB_147 device Main Handle Functions
 ****************************************
 */

/**
 * @brief TCACB_147 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int TCACB_147Init(void)
{
	system(ENABLE_GPIO_51);
	return 0;
}

/**
 * @brief TCACB_147 device Noise value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int TCACB_147Read(char *data, int *len)
{
	char buf[DATA_MAX_SIZE];

	gTCACB_147Fp = fopen(FILE_PATH,"r");
		
	if(gTCACB_147Fp == NULL) {
		sprintf(data,"N/A:READ");
		*len = strlen(data);
		return 0;
	}

	(void)memset(data,0,DATA_MAX_SIZE);
	fgets( buf, DATA_MAX_SIZE, gTCACB_147Fp);
	
	buf[1] = '\0';
	(void)memcpy(data ,buf, strlen(buf));
	*len = strlen(buf);

	fclose(gTCACB_147Fp);
	gTCACB_147Fp = NULL;

	return 0;
}

/**
 * @brief TCACB_147 device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int TCACB_147Close(void)
{
	return 0;
}

