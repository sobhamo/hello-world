/**
 * @file BUT001.c
 *
 * @brief BUT001 Onoff Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "BUT001.h"
#include "Foundation.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define FILE_PATH "/sys/class/gpio/gpio51/value"
#define ENABLE_GPIO_51 "echo 51 > /sys/class/gpio/export"
#define DATA_MAX_SIZE 2

static FILE *gBUT001Fp = NULL;


static char gDummyData[10][20] =
{"1", "1", "0", "1", "0", "0", "0", "1", "0", "0"};
static int gIndex = 0;
/*
 ****************************************
 * BUT001 device Main Handle Functions
 ****************************************
 */

char* BUT001_PRESS(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] ONOFF PRESS");
	return "<xml><device>ONOFF</device><result>PRESS</result></xml>";
}
char* BUT001_RELEASE(char *commandArg)
{
	SPTekDebugLog(LOG_LEVEL_INFO, "[SMA] ONOFF RELEASE");
	return "<xml><device>ONOFF</device><result>RELEASE</result></xml>";
}
/**
 * @brief BUT001 device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int BUT001Init(void)
{
	return 0;
//	system(ENABLE_GPIO_51);
//	RegisterSensorCommand(0x80,"BUT001_PRESS",&BUT001_PRESS);
//	RegisterSensorCommand(0x81,"BUT001_RELEASE",&BUT001_RELEASE);
//	return 0;
}



/**
 * @brief BUT001 Onoff device button value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int BUT001Read(char *data, int *len)
{
	//return dummy
	strcpy(data,gDummyData[gIndex]);
		*len = strlen(data);
		gIndex++;
		gIndex %= 10;
		return 0;
		/*
	char buf[DATA_MAX_SIZE];

	gBUT001Fp = fopen(FILE_PATH,"r");
		
	if(gBUT001Fp == NULL) {
		sprintf(data,"N/A:OPEN");
		*len = strlen(data);
		return 0;
	}

	(void)memset(data,0,DATA_MAX_SIZE);
	fgets( buf, DATA_MAX_SIZE, gBUT001Fp);
	
	buf[1] = '\0';
	(void)memcpy(data ,buf, strlen(buf));
	*len = strlen(buf);

	fclose(gBUT001Fp);
	gBUT001Fp = NULL;

	return 0;
	*/
}

/**
 * @brief BUT001 Onoff device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int BUT001Close(void)
{
	return 0;
}

