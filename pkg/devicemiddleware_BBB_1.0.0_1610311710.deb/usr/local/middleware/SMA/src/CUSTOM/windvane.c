/**
 * @file windvane.c
 *
 * @brief WINDVANE Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "windvane.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gWINDVANENFd;

static char gDummyData[10][20] = 
	{"22.5","45","67.5","90","112.5","135","157.5","180","202.5","225"};
static int gIndex = 0;

/*
 ****************************************
 * WINDVANE device Main Handle Functions
 ****************************************
 */

/**
 * @brief WINDVANE device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int WINDVANEInit(void)
{
	//gWINDVANENFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief WINDVANE device WINDVANE value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int WINDVANERead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief WINDVANE device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int WINDVANEClose(void)
{
	close(gWINDVANENFd);
	return 0;
}

/**
 * @brief WINDVANE Extract WINDVANE value
 * @param[in] Raw Data
 * @return 0 = WINDVANE Value
 */
int getWINDVANEValue(char *data)
{
	return 0;
}

