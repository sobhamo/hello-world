/*
 * @file windvane.h
 *
 * @brief WINDVANE Sensor handler header
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */

#ifndef _WINDVANE_H_
#define _WINDVANE_H_

/*
 ****************************************
 * Enumerations
 ****************************************
 */


/*
 ****************************************
 * Major Functions
 ****************************************
 */

/**
 * @brief WINDVANE device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int WINDVANEInit(void);

/**
 * @brief WINDVANE device button value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-1 => Error ioctl operation
 * 		-2 => Error write operation
 * 		-3 => Error read operation
 */
int WINDVANERead(char *data, int *len);

/**
 * @brief WINDVANE device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int WINDVANEClose(void);


#endif //_WINDVANE_H_
