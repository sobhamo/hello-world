/**
 * @file string.c
 *
 * @brief Custom Sensor Device Handler
 *
 * Copyright (C) 2015. SPTek,All Rights Reserved.
 * Written 2015,by SPTek
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "string.h"

/*
 ****************************************
 * Definition & Global Variable
 ****************************************
 */
#define BUFF_SIZE  128
#define FILE_NAME  "/sys/bus/w1/devices/28-0315030fecff/w1_slave"

static int gSTRINGNFd;

static char gDummyData[10][20] = 
	{"Ten","Nine","Eight","Four","Five","Six","Seven","three","two","one"};
static int gIndex = 0;

/*
 ****************************************
 * STRING device Main Handle Functions
 ****************************************
 */

/**
 * @brief STRING device init function
 * @param[in] No parameter
 * @return	 0 => Success init
 * 		-1 => Error file open
 */
int STRINGInit(void)
{
	//gSTRINGNFd = open(FILE_NAME, O_RDONLY, S_IREAD);
	gIndex = 0;
	return 0;
}

/**
 * @brief STRING device STRING value read funciton
 * @param[in] SPTekSENSOR_INFO_T structure member mLastValue pointer
 * @return	 0 => Success read data
 * 		-3 => Error read operation
 * 		-4 => Error lseek operation
 */
int STRINGRead(char *data, int *len)
{
	strcpy(data,gDummyData[gIndex]);
	*len = strlen(data);
	gIndex++;
	gIndex %= 10;
	return 0;
}

/**
 * @brief STRING device close funciton
 * @param[in] No parameter
 * @return 0 = default
 */
int STRINGClose(void)
{
	close(gSTRINGNFd);
	return 0;
}

/**
 * @brief STRING Extract STRING value
 * @param[in] Raw Data
 * @return 0 = STRING Value
 */
int getSTRINGValue(char *data)
{
	return 0;
}

