/**
 * @file SimpleXMLParser.h
 *
 * @brief Simple XML parser header file
 *
 * Copyright (C) 2016. SK Telecom, All Rights Reserved.
 * Written 2016, by SK Telecom
 */

#ifndef _SIMPLE_XML_PARSER_
#define _SIMPLE_XML_PARSER_

void SimpleXMLParser(char* payload, char* name, char* value, int isPC);

#endif
