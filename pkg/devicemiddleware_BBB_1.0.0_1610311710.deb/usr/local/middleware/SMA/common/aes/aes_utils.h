extern int aes_utils_make16Drainage(int length);


/**
 * \brief          Generate random key
 *
 * \param keybits  must be 128, 192 or 256
 *
 * \return char*   key
 */
extern unsigned char* aes_utils_generateKey(int keybits);


/**
 * \brief          AES-CBC buffer encryption/decryption
 *                 Length should be a multiple of the block
 *                 size (16 bytes)
 *
 * \note           Upon exit, the content of the IV is updated so that you can
 *                 call the function same function again on the following
 *                 block(s) of data and get the same result as if it was
 *                 encrypted in one call. This allows a "streaming" usage.
 *                 If on the other hand you need to retain the contents of the
 *                 IV, you should either save it manually or use the cipher
 *                 module instead.
 *
 * \param ctx      AES context
 * \param mode     MBEDTLS_AES_ENCRYPT or MBEDTLS_AES_DECRYPT
 * \param length   length of the input data
 * \param iv       initialization vector (updated after use)
 * \param input    buffer holding the input data
 * \param output   buffer holding the output data
 *
 * \return         0 if successful, or MBEDTLS_ERR_AES_INVALID_INPUT_LENGTH
 */
extern int aes_utils_cbc( mbedtls_aes_context *ctx,
                    int mode,
					size_t length,
                    unsigned char iv[16],
                    const unsigned char *input,
                    unsigned char *output );
				
/**
 * \brief          AES-ECB block encryption/decryption
 *
 * \param ctx      AES context
 * \param mode     MBEDTLS_AES_ENCRYPT or MBEDTLS_AES_DECRYPT
 * \param input    16-byte input block
 * \param output   16-byte output block
 *
 * \return         0 if successful
 */
extern int aes_utils_ecb( mbedtls_aes_context *ctx,
                    int mode,
					size_t length,
                    const unsigned char *input,
                    unsigned char *output );	
void hexToAscii(char *in, int len, char* out);
void asciiToHex(char *in, int len, char* out);
					
