
/**
 *
 * 정보조회 > 네트워크 정보
 *
 */

(function () {

	$(function () {

		init();

	});

	// 페이지 초기화
	var init = function () {

		// 핑
		ipc.send("ping", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				if (res.isAlive) {
					$("#DM_CONNECTION").text(__("인터넷이 정상적으로 연결됨"));
				} else {
					$("#DM_CONNECTION").text(__("네트워크 연결상태를 확인하세요"));
				}
			}
		});

		// 네트웤크 정보
		ipc.send("getNetworkInfo", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

				// {DM_RESULT: 1, DM_CONNECTION_TYPE: 1, DM_IP_ADDRESS: "127.0.0.1", DM_SUBNET_MASK: "255.255.255.0", DM_GATEWAY: "127.0.0.1"…}
				if (res.DM_CONNECTION_TYPE == IPC.DM_DHCP_TYPE) {
					$("#DM_CONNECTION_TYPE").text(__("동적 IP 할당 방식"));
				} else {
					$("#DM_CONNECTION_TYPE").text(__("정적 IP 할당 방식"));
				}

				$("#DM_GATEWAY").text(res.DM_GATEWAY);
				$("#DM_IP_ADDRESS").text(res.DM_IP_ADDRESS);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_PRI_DNS_SERVER").text(res.DM_PRI_DNS_SERVER);
				$("#DM_SUB_DNS_SERVER").text(res.DM_SUB_DNS_SERVER);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_SUBNET_MASK").text(res.DM_SUBNET_MASK);
			}
		});
	};
})();