
/**
 *
 * 정보조회 > 시스템 정보
 *
 */

(function () {

	var BASE_DOM = false;

	$(function () {

		// BASE DOM 
		BASE_DOM = $(".sensor_list tr:first").clone();
		$(".sensor_list tr:first").remove();

		information_system.init();
	
	});
	
	
	
	
	
	window.information_system = {
			
		index : 0,
		
		init : function () {
			var that = this;
			
			// 시스템 정보
			ipc.send("getSystemInfo", false, function (res) {
				
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}
					$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
					$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
					$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);

					$("#DM_CPU_USAGE").text(res.DM_CPU_TYPE);
					$("#DM_RAM_USAGE").text(res.DM_RAM_TYPE);
					$("#DM_BATTERY_USAGE").text(res.DM_BATTERY_TYPE);
				}
			});
			
			// 센서 리스트
			ipc.send("getDevice", false, function (res) {
				if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
					that.getAllDeviceSensorStatus(res.DM_DEVICE_ID);
				}
			});
		},
		
		getAllDeviceSensorStatus : function(DEVICE_LIST){
			
			console.log("getAllDeviceSensorStatus");
			console.log("DEVICE_LIST : ", DEVICE_LIST);
			
			var that = this;
			
			if(this.index < DEVICE_LIST.length){
				
				var params = new Params();
				params.put("DM_DEVICE_ID", DEVICE_LIST[this.index]);
				
				ipc.send("getAllDeviceSensorStatus", params, function (res) {
					if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
						
						for (var q in res.DM_SENSOR_ARRAY) {

							var sensor = res.DM_SENSOR_ARRAY[q];

							var tr = BASE_DOM.clone();
							// BeagleBone Black &gt; Hub &gt; 센서
							//tr.find(".sensor_path").text("BeagleBone Black > " + __("센서"));
							tr.find(".sensor_path").text(sensor.DM_DEVICE_ID + " > " + __("센서"));
							tr.find(".sensor_name").text(sensor.DM_SENSOR_TYPE + "(" + sensor.DM_SENSOR_NAME + ")");
							

							if (!sensor.DM_DEVICE_ID || $.trim(sensor.DM_DEVICE_ID) == "") continue;

							var DM_SENSOR_STATUS = (sensor.DM_SENSOR_STATUS == "N/A") ? sensor.DM_SENSOR_STATUS : JSON.parse(sensor.DM_SENSOR_STATUS);
							// 연결상태
							if (DM_SENSOR_STATUS != "N/A" && DM_SENSOR_STATUS.status == "on") {
								tr.find(".sensor_status").text("Online");
							} else {
								tr.find(".sensor_status").text("Offline");
							}

							$(".sensor_list").append(tr);
						}
						that.getAllDeviceSensorStatus(DEVICE_LIST);

					}
				});
				
				this.index++;
			}
		}
		
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	
	
	
	
	
	

	// 페이지 초기화
	var init = function () {

		// 시스템 정보
		ipc.send("getSystemInfo", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
				// {"DM_RESULT":1,"DM_DEVICE_MODEL":"Model Name","DM_CPU_TYPE":"CPU 1.5Ghz","DM_RAM_TYPE":"4.0G","DM_BATTERY_TYPE":"1.0","DM_SERIAL_NUMBER":"0xd2dfefea","DM_MAC_ADDRESS":"MA-AA-DC-EF-AE"}
				$("#DM_DEVICE_MODEL").text(res.DM_DEVICE_MODEL);
				$("#DM_MAC_ADDRESS").text(res.DM_MAC_ADDRESS);
				$("#DM_SERIAL_NUMBER").text(res.DM_SERIAL_NUMBER);

				$("#DM_CPU_USAGE").text(res.DM_CPU_TYPE);
				$("#DM_RAM_USAGE").text(res.DM_RAM_TYPE);
				$("#DM_BATTERY_USAGE").text(res.DM_BATTERY_TYPE);
			}
		});

		// 센서 리스트
		ipc.send("getDevice", false, function (res) {
			
			if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {

				for (var q in res.DM_DEVICE_ID) {


					setTimeout((function (device_id) {
						
						var params = new Params();
						params.put("DM_DEVICE_ID", device_id);

						ipc.send("getAllDeviceSensorStatus", params, function (res) {
							
							if (res.DM_RESULT == IPC.DM_RESULT_SUCCESS) {
								
								for (var q in res.DM_SENSOR_ARRAY) {

									var sensor = res.DM_SENSOR_ARRAY[q];

									var tr = BASE_DOM.clone();
									// BeagleBone Black &gt; Hub &gt; 센서
									//tr.find(".sensor_path").text("BeagleBone Black > " + __("센서"));
									tr.find(".sensor_path").text(sensor.DM_DEVICE_ID + " > " + __("센서"));
									tr.find(".sensor_name").text(sensor.DM_SENSOR_TYPE + "(" + sensor.DM_SENSOR_NAME + ")");
									

									if (!sensor.DM_DEVICE_ID || $.trim(sensor.DM_DEVICE_ID) == "") continue;

									var DM_SENSOR_STATUS = (sensor.DM_SENSOR_STATUS == "N/A") ? sensor.DM_SENSOR_STATUS : JSON.parse(sensor.DM_SENSOR_STATUS);
									// 연결상태
									if (DM_SENSOR_STATUS != "N/A" && DM_SENSOR_STATUS.status == "on") {
										tr.find(".sensor_status").text("Online");
									} else {
										tr.find(".sensor_status").text("Offline");
									}

									$(".sensor_list").append(tr);
								}
							}
						});
					})(res.DM_DEVICE_ID[q]), 300);
				}
			}
		});
	};
	
	*/
	
	
	
	
	
})();