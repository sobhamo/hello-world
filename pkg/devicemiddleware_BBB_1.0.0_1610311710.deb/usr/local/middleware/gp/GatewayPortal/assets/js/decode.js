
var decode = {};

module.exports = decode;

var define = require('./define');
var logger = require('log4js').getLogger('Client');
var hexy = require('hexy');
var crypto = require('crypto');
var showPacket = false;


decode.decode = function(message){
	
	var header = {};
	var content = {};
	var error;

	if(showPacket) logger.debug('\n'+ hexy.hexy(message));
	
	try{
		header = this.decodeHeader(message);
		content = this.decodeContent(header.messageType, header.content);
	}catch(err){
		
		// error = err;
		// console.error("*******************************************************");
		// console.error("*******************************************************");
		// console.error("**                                                   **");
		// console.error("**                                                   **");
		// console.error(err);
		// console.error("**                                                   **");
		// console.error("**                                                   **");
		// console.error("*******************************************************");
		// console.error("*******************************************************");
	}
//	console.log(header);
//	console.log(content);
//	console.log("--------------------------------------");
	return{
		header : header,
		content : content,
		error : error
	}
}

// 헤드 디코딩
decode.decodeHeader = function(packet){
	
	var header = {};
	var offset = 0;
	
	header.destination = packet.toString('binary', offset, define.HEADER_DESTINATION_END_OFFSET);
	offset = define.HEADER_DESTINATION_END_OFFSET;
	
	// ZMQ 특성상 먼저 Destination만 들어있는 메시지가 온 후 바로 메인 메시지가 들어옴
	if(packet.length != 16){
		header.source = packet.toString('binary', offset, define.HEADER_SOURCE_END_OFFSET);
		offset = define.HEADER_SOURCE_END_OFFSET;
		
		header.messageType = Number(packet.toString('binary', offset, define.HEADER_TYPE_END_OFFSET));
		offset = define.HEADER_TYPE_END_OFFSET;
		
		header.reserved = packet.toString('binary', offset, define.HEADER_RESERVED_END_OFFSET);
		offset = define.HEADER_RESERVED_END_OFFSET;
		
		header.contentsLength = packet.toString('binary', offset, define.HEADER_LENGTH_END_OFFSET);
		offset = define.HEADER_LENGTH_END_OFFSET;
		
		if (header.messageType == 1000) {
			
			header.content = packet.slice(offset, offset + Number(header.contentsLength));
			
		} else {
			
			ciphertext = packet.slice(offset, offset + Math.ceil(Number(header.contentsLength) / 16)*16);

			var decipher = crypto.createDecipheriv("aes-128-cbc", define.encrptionKey, define.encrptionIV);
			decipher.setAutoPadding(false);
			
			var deciphertext = decipher.update(ciphertext);
			deciphertext = Buffer.concat([deciphertext, decipher.final()]);
			
			header.content = deciphertext.slice(0, Number(header.contentsLength));			
		
		}
			
	}
	return header;
}

// Decode Body
decode.decodeContent = function(contentType, content){
	
	var obj = {};
	var offset = 0;
	var contentLength = content.length;
	var T, L, V;
	
	switch(contentType){
	
	case define.AUTHENTICATION:
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_HAS_ACCOUNT : // DM_HAS_ACCOUNT : Log trace status
					obj.DM_HAS_ACCOUNT = content.readUInt16LE(offset);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;

		
	case define.EXTRA_INFO:
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_SERVER_URL : // DM_SERVER_URL : ThingPlug server URL
					obj.DM_SERVER_URL = content.toString('binary', offset, offset + L);
					break;
				case define.DM_MW_CURRENT_VER : // DM_MW_CURRENT_VER : MiddleWare current version
					obj.DM_MW_CURRENT_VER = content.toString('binary', offset, offset + L);
					break;
				case define.DM_MW_LATEST_VER : // DM_MW_LATEST_VER : MiddleWare latest version
					obj.DM_MW_LATEST_VER = content.toString('binary', offset, offset + L);
					break;
				case define.DM_TRACE_STATUS : // DM_TRACE_STATUS : Log trace status
					obj.DM_TRACE_STATUS = content.readUInt16LE(offset);
					break;
				case define.DM_TIMEZONE : // DM_TIMEZONE : Log timezone
					obj.DM_TIMEZONE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SET_TIME : // DM_SET_TIME : Set device time
					obj.DM_SET_TIME = content.toString('binary', offset, offset + L);
					break;
				case define.DM_TIME_SYNC : // DM_TIME_SYNC : Set device time sync with NTP server
					obj.DM_TIME_SYNC = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
	case define.REGISTER:
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;

			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_ENC_KEY : // 
					obj.DM_ENC_KEY = content.toString('binary', offset, offset + L);
					break;
				case define.DM_ENC_IV : // 
					obj.DM_ENC_IV = content.toString('binary', offset, offset + L);
					break;
				case define.DM_HAS_ACCOUNT : 
					obj.DM_HAS_ACCOUNT = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		
		define.encrptionKey = obj.DM_ENC_KEY;
		define.encrptionIV = obj.DM_ENC_IV;
		
		break;
		

	case define.IV:
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;

			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_ENC_IV : // 
					obj.DM_ENC_IV = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		
		define.encrptionTempIV = obj.DM_ENC_IV;
		
		break;	
		
		
	case define.GET_DEVICE:
		
		obj.DM_DEVICE_ID = [];
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_DEVICE_ID : // DM_DEVICE_MODEL : 디바이스모델명
					obj.DM_DEVICE_ID.push(content.toString('binary', offset, offset + L));
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;

		
	case define.GET_SYSTEM_INFO :
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_DEVICE_MODEL : // DM_DEVICE_MODEL : 디바이스모델명
					obj.DM_DEVICE_MODEL = content.toString('binary', offset, offset + L);
					break;
				case define.DM_CPU_TYPE : // DM_CPU_TYPE : CPU정보
					obj.DM_CPU_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_RAM_TYPE : // DM_RAM_TYPE : RAM정보
					obj.DM_RAM_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_BATTERY_TYPE : // DM_BATTERY_TYPE : 배터리정보
					obj.DM_BATTERY_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SERIAL_NUMBER : // DM_SERIAL_NUMBER : 일련번호
					obj.DM_SERIAL_NUMBER = content.toString('binary', offset, offset + L);
					break;
				case define.DM_MAC_ADDRESS : // DM_MAC_ADDRESS : MAC 주소
					obj.DM_MAC_ADDRESS = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_PROTOCOL_TYPE : // DM_IOT_PROTOCOL_TYPE : MAC 주소
					obj.DM_IOT_PROTOCOL_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_DEVICE_NAME : // DM_IOT_DEVICE_NAME : MAC 주소
					obj.DM_IOT_DEVICE_NAME = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_SP_USE_FLAG : // DM_IOT_SP_USE_FLAG : MAC 주소
					obj.DM_IOT_SP_USE_FLAG = content.readUInt16LE(offset);
					break;
				case define.DM_IOT_UKEY : // DM_IOT_UKEY : Ukey
					obj.DM_IOT_UKEY = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_SERVICE_ID : // DM_IOT_SERVICE_ID : MAC 주소
					obj.DM_IOT_SERVICE_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_AUTH_ID : // DM_IOT_AUTH_ID : MAC 주소
					obj.DM_IOT_AUTH_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_MANUFACTURE_ID : // DM_IOT_MANUFACTURE_ID : MAC 주소
					obj.DM_IOT_MANUFACTURE_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_SERVER_PORT : // DM_IOT_SERVER_PORT : MAC 주소
					obj.DM_IOT_SERVER_PORT = content.toString('binary', offset, offset + L);
					break;
				case define.DM_IOT_TP_ID : // DM_IOT_TP_ID : MAC 주소
					obj.DM_IOT_TP_ID = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
		
	case define.GET_SYSTEM_USAGE :
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;

			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_DEV_CPU_USAGE : // DM_CPU_USAGE : CPU 사용량
					obj.DM_DEV_CPU_USAGE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_DEV_RAM_USAGE : // DM_RAM_USAGE : RAM 사용량
					obj.DM_DEV_RAM_USAGE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_BATTERY_USAGE : // DM_BATTERY_USAGE : CPU 사용량
					obj.DM_BATTERY_USAGE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_CPU_USAGE : // DM_CPU_USAGE : CPU 사용량
					obj.DM_CPU_USAGE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_RAM_USAGE : // DM_MEM_USAGE : RAM 사용량
					obj.DM_RAM_USAGE = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
		
	case define.GET_INTERVAL : 

		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_SENSOR_GATHER_INTERVAL : // DM_SENSOR_GATHER_INTERVAL : 센서정보수집주기
					obj.DM_SENSOR_GATHER_INTERVAL = content.readUInt16LE(offset);
					break;
				case define.DM_SENSOR_SERVER_UPDATE_INTERVAL : // DM_SENSOR_SERVER_UPDATE_INTERVAL : 센서정보서버 UDPATE주기
					obj.DM_SENSOR_SERVER_UPDATE_INTERVAL = content.readUInt16LE(offset);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";

			}
			offset += L;
		}
		break;
		
		
	case define.GET_NETWORK_INFO :
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_CONNECTION_TYPE : // DM_CONNECTION_TYPE : 연결방식
					obj.DM_CONNECTION_TYPE = content.readUInt8(offset);
					break;
				case define.DM_IP_ADDRESS : // DM_IP_ADDRESS : IPADDRESS
					obj.DM_IP_ADDRESS = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SUBNET_MASK : // DM_SUBNET_MASK : 서브넷마스크
					obj.DM_SUBNET_MASK = content.toString('binary', offset, offset + L);
					break;
				case define.DM_GATEWAY : // DM_GATEWAY : 게이트웨이
					obj.DM_GATEWAY = content.toString('binary', offset, offset + L);
					break;
				case define.DM_PRI_DNS_SERVER : // DM_PRI_DNS_SERVER : PRI DNS 서버
					obj.DM_PRI_DNS_SERVER = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SUB_DNS_SERVER : // DM_SUB_DNS_SERVER : SUB DNS 서버
					obj.DM_SUB_DNS_SERVER = content.toString('binary', offset, offset + L);
					break;
				case define.DM_MAC_ADDRESS : // DM_MAC_ADDRESS : MAC 주소
					obj.DM_MAC_ADDRESS = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
		
	case define.GET_DEVICE_SENSOR :
	case define.GET_ALL_DEVICE_SENSOR_STATUS :
		
		obj.DM_SENSOR_ARRAY = [];
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_SENSOR_ARRAY : // DM_SENSOR_ARRAY : 센서 ARRAY
					 V = content.slice(offset, offset + L);
					 obj.DM_SENSOR_ARRAY.push(decode.decodeContent(define.DM_SENSOR_ARRAY, V));
					 //console.log(obj.DM_SENSOR_ARRAY.length);
					 //console.log(obj);
					 break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;

		
		
	case define.DM_SENSOR_ARRAY:
		
		
		obj = new Object();
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_DEVICE_ID : // DM_DEVICE_ID : 디바이스 ID (예 “DEVICE-0”)
					obj.DM_DEVICE_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_ID : // DM_SENSOR_ID : 센서 ID 	(예 “A000000001")
					obj.DM_SENSOR_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_NAME : // DM_SENSOR_NAME : 센서이름 	(예 “DS18B20”)
					obj.DM_SENSOR_NAME = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_TYPE : // DM_SENSOR_TYPE : 센서타입 	(예 “temperature”,  “motiondetect”)
					obj.DM_SENSOR_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_SERIAL : // DM_SENSOR_SERIAL : 센서 일련번호
					obj.DM_SENSOR_SERIAL = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_STATUS : // DM_SENSOR_STATUS : 센서상태 (Online, Offline) (JSON포맷)
					obj.DM_SENSOR_STATUS = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_DATA : // DM_SENSOR_DATA : 센서데이터(JSON포맷)
					obj.DM_SENSOR_DATA	 = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_CYCLE : // DM_SENSOR_CYCLE : collecting cycle
					obj.DM_SENSOR_CYCLE	 = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_CHECK_CYCLE : // DM_SENSOR_CHECK_CYCLE : max cycle
					obj.DM_SENSOR_CHECK_CYCLE	 = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_OPERATION_TYPE : // DM_SENSOR_OPERATION_TYPE : event type or time series type
					obj.DM_SENSOR_OPERATION_TYPE = content.readUInt16LE(offset);
					break;
				case define.DM_SENSOR_CONTROL_TYPE : // DM_SENSOR_CONTROL_TYPE : no control or controlable
					obj.DM_SENSOR_CONTROL_TYPE = content.readUInt16LE(offset);
					break;
				case define.DM_CRITICAL_COUNT : // DM_CRITICAL_COUNT : 센서 Critical 레벨 오류count
					obj.DM_CRITICAL_COUNT = content.readUInt16LE(offset);
					break;
				case define.DM_MAJOR_COUNT : // DM_MAJOR_COUNT : 센서 Major 레벨 오류count
					obj.DM_MAJOR_COUNT = content.readUInt16LE(offset);
					break;
				case define.DM_MINOR_COUNT : // DM_MINOR_COUNT : 센서 Minor 레벨 오류count
					obj.DM_MINOR_COUNT = content.readUInt16LE(offset);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
		
	case define.GET_DEVICE_SENSOR_STATUS :
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_DEVICE_ID : // DM_DEVICE_ID : 디바이스 ID
					obj.DM_DEVICE_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_ID : // DM_SENSOR_ID : 센서 ID
					obj.DM_SENSOR_ID = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_NAME : // DM_SENSOR_NAME : 센서이름
					obj.DM_SENSOR_NAME = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_TYPE : // DM_SENSOR_TYPE : 센서타입
					obj.DM_SENSOR_TYPE = content.toString('binary', offset, offset + L);
					break;
				case define.DM_SENSOR_STATUS : // DM_SENSOR_STATUS : 센서상태 (Online, Offline) (JSON포맷)
					var data = content.toString('binary', offset, offset + L);
					if(typeof data == "string")
						obj.DM_SENSOR_STATUS = data;	
					else
						obj.DM_SENSOR_STATUS = JSON.parse(data);
					break;
				case define.DM_SENSOR_DATA : // DM_SENSOR_DATA : 센서데이터(JSON포맷)
					var data = content.toString('binary', offset, offset + L);
					if(typeof data == "string")
						obj.DM_SENSOR_DATA = data;	
					else
						obj.DM_SENSOR_DATA = JSON.parse(data);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
		
	case define.GET_SYSTEM_LOG :
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_LOG_DATA : // DM_LOG_DATA : Log Data
					obj.DM_LOG_DATA = JSON.parse(content.toString('binary', offset, offset + L));
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		
	case define.REGISTER_DEVICE :
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_FAIL_MESSAGE : // DM_FAIL_MESSAGE : fail message
					obj.DM_FAIL_MESSAGE = content.toString('binary', offset, offset + L);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
	
		
	case define.RESET 				:
	case define.RESTART 			:
	case define.LOG_RESET			:
	case define.UPDATE_LOG 			:
	case define.CHANGE_AUTH 		:
	case define.SET_INTERVAL 		:
	case define.ACCOUNT			 	:
	case define.UNREGISTER_DEVICE 	:

		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case 0x01 : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
	
		

	case define.GET_PROCESS_STATUS : 
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_SRA_PROCESS_STATUS : // DM_SRA_PROCESS_STATUS : SRA 상태
					obj.DM_SRA_PROCESS_STATUS = content.readUInt16LE(offset);
					break;
				case define.DM_CRA_PROCESS_STATUS : // DM_CRA_PROCESS_STATUS : CRA 상태
					obj.DM_CRA_PROCESS_STATUS = content.readUInt16LE(offset);
					break;
				case define.DM_MA_PROCESS_STATUS : // DM_MA_PROCESS_STATUS : MA 상태
					obj.DM_MA_PROCESS_STATUS = content.readUInt16LE(offset);
					break;
				case define.DM_SMA_PROCESS_STATUS : // DM_MA_PROCESS_STATUS : MA 상태
					obj.DM_SMA_PROCESS_STATUS = content.readUInt16LE(offset);	
					break;
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
	case define.GET_THING_STATUS :
		
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
				case define.DM_IOT_DEV_REG_STATE : // 자기자신IOT등록상태 (IOT REG STATE Code 참조)
					obj.DM_IOT_DEV_REG_STATE = content.readUInt16LE(offset);
					break;
				case define.DM_IOT_THING_STATUS : // ThingPlug 연결상태 (THING STATUS Code 참조)
					obj.DM_IOT_THING_STATUS = content.readUInt16LE(offset);
					break;
				case define.DM_IOT_PROTOCOL_TYPE:
					obj.DM_IOT_PROTOCOL_TYPE = content.toString('binary', offset, offset + L);
					break;
					
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
		

		
	case define.GET_ERROR_LOG_COUNT :
		
		obj.DM_SENSOR_ARRAY = [];
		while(offset < contentLength){
			T = content.readUInt8(offset);
			offset += 1;
			L = content.readUInt16LE(offset);
			offset += 2;
			
			switch(T){
				case define.DM_RESULT : // DM_RESULT : RESULT_CODE
					obj.DM_RESULT = content.readUInt8(offset);
					break;
					
				case define.DM_CRITICAL_COUNT : // DM_CRITICAL_COUNT : RESULT_CODE
					obj.DM_CRITICAL_COUNT = content.readUInt16LE(offset);
					break;
					
				case define.DM_MAJOR_COUNT : // DM_MAJOR_COUNT : RESULT_CODE
					obj.DM_MAJOR_COUNT = content.readUInt16LE(offset);
					break;
									
				case define.DM_MINOR_COUNT : // DM_MINOR_COUNT : RESULT_CODE
					obj.DM_MINOR_COUNT = content.readUInt16LE(offset);
					break;
					
				case define.DM_SENSOR_ARRAY : // DM_SENSOR_ARRAY : RESULT_CODE
					V = content.slice(offset, offset + L);
					
					obj.DM_SENSOR_ARRAY.push(decode.decodeContent(define.DM_SENSOR_ARRAY, V));
					break;
					
				default : 
					throw "message decode error ("+ contentType +"): unknown messageType ("+ T +")";
			}
			offset += L;
		}
		break;
		
	default :
		throw "message decode error : unknown messageType";
	
	}
	offset = null;
	contentLength = null;
	T = L = V = null;
	return obj;
}





