/**
 * 시스템 공용 스크립트
 *
 */

/**
 * 공통 초기화
 */
 
var popup_option = {
	modalClose : false, 
	positionStyle : "fixed", 
	follow : [ true, true ]
}

var Init = function(){

	// 빈값 체크
	$.fn.Empty = function(msg) {
		if (!$(this).val().trim()) {
			alert(msg);
			$(this).focus();
			return true;
		} else {
			return false;
		}
	};
	
	
	// Page timeout check and redirection
	
	var date = new Date();
	var m = 15;
	date.setTime(date.getTime() + (m * 60 * 1000));

	$.cookie("screenTimeOut", null, { path: "/", expires : -1 });
	$.cookie("screenTimeOut", "on", { path: "/", expires: date, secure : false });
	
	
	if (location.pathname != "/"){
		
		setInterval(function () {

			if($.cookie("screenTimeOut") == undefined || $.cookie("screenTimeOut") == null || $.cookie("screenTimeOut") == ""){
				$.cookie("screenTimeOut", null, { path: "/", expires : -1 });
				alert(__("시간이 초과하여 초기화면으로 이동합니다."));
				setTimeout(function() {window.location.href = "/PageTimeout";}, 2000);
			};
		
		}, 901000);

	}
	
};

/**
 * sendAjax
 *
 * @param (string) url 서버주소
 * @param (object) data 전달데이터
 * @param (function) sf 정상처리 콜백함수
 * @param (function) ef 에러처리 콜백함수
 *
 * @comment
 *    - ajax 통신
 */
var sendAjax = function(url, form, sf, ef){
	var send_data = null;

	log("---------------------------------------");
	log("   ------ [Request] ------");
	log("      Request URL : " + url);
	log("      Form data :");
	if(form){
		if(form.attr) log(form_print(form));
		else log(object_print(form.serialize()));
		send_data = form.serialize();
	}

	$.ajax({
		type : "post",
		datatype : "json",
		data : send_data,
		url : url,
		success : function(_data){

			log("   ------ [Response] ------");
			log(object_print(_data));
			log("---------------------------------------");
			log("");

			if(typeof(sf) != "undefined" && typeof(sf) == "function") sf(_data);
		},
		error : function(e, s, m){
			if(typeof(ef) != "undefined" && typeof(ef) == "function") ef(e, s, m);
		},
		// 전송전 스피너 처리
		beforeSend : function(){
			;
		},
		// 전송후 스피너 처리
		complete : function(){
			;
		}
	});
};

/**
 * thingplug_ajax
 * 
 */
var thingplug_ajax = function(url, ID, PASS, sf){
	var send_data = null;

	log("---------------------------------------");
	log("   ------ [Request] ------");
	log("      Request URL : " + url);

	$.ajax({
		type : "put",
		dataType : "jsonp",
		url : url,
		headers : {
			"user_id" : ID, 
			"password" : PASS, 
			"locale" : "ko"
		},
		success : function(_data){

			log("   ------ [Response] ------");
			log(object_print(_data));
			log("---------------------------------------");
			log("");

			if(typeof(sf) != "undefined" && typeof(sf) == "function") sf(_data);
		}
	});
};

/**
 * sendAjax 성공여부
 *
 * @param (object) res
 *
 * @comment
 */
var isAjaxOK = function(res){

	return res.code == "200";
	//else if(ajax.type == "xml" || ajax.type == "XML") return res.find("code").text() == "S200";
	//else return true;
};

/**
 * 로그출력
 *
 * @param (string) msg 로그 메시지
 *
 * @comment
 *    - 콘솔 디버깅
 */
var log = function(msg){
	//if(typeof(console) != "undefined" && console) console.log(msg);
};

/**
 * 디버그 Form 객체 데이터
 *
 * @param (string) form 객체
 *
 * @return (string) 디버그 값
 *
 * @comment
 *    - form 디버깅.
 */
var form_print = function(obj){
	if(!obj) return "";
	var str = '{ \n';
	var hashes = obj.serialize().split("&");
	for(var i = 0; i < hashes.length; i++){
		var hash = hashes[i].split("=");
		str += '    "' + hash[0] + '" : "' + hash[1] + '"\n';
	}
	str += ' }';
	return str;
};

/**
 * 오브젝트 디버깅
 *
 * @param (Array) obj 오브젝트
 * @param (integer) index 값
 *
 * @return (string) 디버그 값
 *
 */
var object_print = function(obj, i){
	var ii = 0;
	if(i > 0) ii = i;
	var str = '{ \n';
	var data = obj;
	for(var p in data){
		var tmp = eval("data['" + p.toString() + "']");
		if(typeof(tmp) == "object"){
			str +=  '    "' + p.toString() + '" : ' + this.object_print(tmp, ii + 1) + "\n";
		}else if(tmp != null && tmp.toString != null && tmp.toString() != ''){
			if(ii > 0){
				for(var k = 0; k < ii; k++) str += '    ';
			}
			str += '    "' + p.toString() + '" : "' + tmp.toString() + '"';
			if(str != '') str += "\n";
		}
	}
	if(ii > 0){
		for(var k = 0; k < ii; k++) str += '    ';
	}
	str += ' }';
	return str;
};

var number_format = function(number){
	var str = number + "";
    var Re = /[^0-9]/g;
    var ReN = /(-?[0-9]+)([0-9]{3})/;
    str = str.replace(Re,'');
    while(ReN.test(str)) {
		str = str.replace(ReN, "$1,$2");
	}
	return str;
};

/**
 * GET 파라미터 추출.
 *
 * @return (array) GET 배열(키:값)
 *
 * @comment
 * 		- 사용법 : var str = getParams()[키값];
 */
var getParams = function(){
	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf("?") + 1).split("&");
	for(var i = 0; i < hashes.length; i++){
		hash = hashes[i].split("=");
		vars.push(hash[0]);
		vars[hash[0]] = hash[1];
	}
	return vars;
};


/**
 * String replaceAll 구현
 *
 */
String.prototype.replaceAll = function(o, n){
	return this.split(o).join(n);
};


/**
 * ajax 파라미터 클래스
 */
var Params = function(){

	this.data = {};

	/**
	 * 파라미터 키, 값 추가
	 * @param k
	 * @param v
	 * @returns
	 */
	this.put = function(k, v){
		//this.data[k] = encodeURIComponent(v);
		this.data[k] = v;
	}

	/**
	 * 파라미터 추출 : json
	 * @returns
	 */
	this.serialize = function(){
		return this.data;
	};

	/**
	 * 초기화
	 *
	 */
	this.clear = function(){
		this.data = {};
	};
};

// alert 대체용
var alert = function (msg) {
	
	$("#alert_modal h2").text(msg);
	$("#alert_modal").bPopup(popup_option);

	setTimeout(function () {
		$("#alert_modal").bPopup().close();
	}, 1300);
};

$(function(){

	Init();
});