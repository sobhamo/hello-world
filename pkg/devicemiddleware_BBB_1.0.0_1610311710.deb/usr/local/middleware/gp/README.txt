﻿# 간단 설명
  - /server.js 어플리케이션 서버 스크립트
  - /assets/css 스타일시트 폴더
  - /assets/font 폰트 폴더
  - /assets/images 이미지 폴더
  - /assets/js 서버 스크립트 폴더
     - /assets/js/lang 언어팩 스크립트 폴더
     - /assets/js/lib 라이브러리 스크립트 폴더
     - /assets/js/mobule 사용자 어플리케이션 모듈별 스크립트 폴더
  - /html 화면단(ejs) 폴더
    - /html/common 공통 폴더


wget https://download.libsodium.org/libsodium/releases/libsodium-1.0.3.tar.gz -d

tar xvfz libsodium-1.0.3.tar.gz 
cd libsodium-1.0.3

./configure 
make
make install


wget http://download.zeromq.org/zeromq-3.2.3.tar.gz
tar -zxvf zeromq-3.2.3.tar.gz
cd zeromq-3.2.3
./configure
make
sudo make install


npm install zmq
